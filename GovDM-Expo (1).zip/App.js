import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import { AppProvider, useApp } from './src/state/AppContext';
import { GovPalette } from './src/theme/theme';

import MainTabs from './src/navigation/MainTabs';
import OnboardingScreen, { LoginScreen } from './src/screens/OnboardingScreen';
import SearchScreen from './src/screens/SearchScreen';
import SettingsScreen from './src/screens/SettingsScreen';
import HealthScreen from './src/screens/HealthScreen';
import AgricultureScreen from './src/screens/AgricultureScreen';
import TourismScreen, { TourismSiteDetailScreen } from './src/screens/TourismScreen';
import {
  OfficeDetailScreen,
  AppointmentBookingScreen,
} from './src/screens/OfficeDirectoryScreen';
import {
  NewServiceRequestScreen,
  ServiceRequestDetailScreen,
  MyServiceRequestsScreen,
  PublicWorksScreen,
} from './src/screens/ServiceScreens';
import {
  NewReportScreen,
  ReportDetailScreen,
  TrackReportScreen,
  AllAnnouncementsScreen,
  AnnouncementDetailScreen,
  AllAlertsScreen,
} from './src/screens/ReportScreens';
import {
  ShelterListScreen,
  ChecklistScreen,
  OfflineGuideScreen,
  EmergencyContactsScreen,
  EmergencyScreen,
} from './src/screens/DisasterScreens';

const Stack = createNativeStackNavigator();

function RootNavigator() {
  const { hasCompletedOnboarding } = useApp();

  return (
    <Stack.Navigator screenOptions={{ headerTintColor: GovPalette.jungle }}>
      {!hasCompletedOnboarding ? (
        <Stack.Screen name="Onboarding" component={OnboardingScreen} options={{ headerShown: false }} />
      ) : (
        <Stack.Screen name="Main" component={MainTabs} options={{ headerShown: false }} />
      )}

      <Stack.Screen
        name="Login"
        component={LoginScreen}
        options={{ presentation: 'modal', title: 'Create Account' }}
      />
      <Stack.Screen name="Search" component={SearchScreen} options={{ presentation: 'modal', title: 'Search' }} />
      <Stack.Screen name="Settings" component={SettingsScreen} options={{ title: 'Settings' }} />

      <Stack.Screen name="Health" component={HealthScreen} options={{ title: 'Health' }} />
      <Stack.Screen name="Agriculture" component={AgricultureScreen} options={{ title: 'Agriculture & Fisheries' }} />
      <Stack.Screen name="Tourism" component={TourismScreen} options={{ title: 'Discover Dominica' }} />
      <Stack.Screen name="TourismSiteDetail" component={TourismSiteDetailScreen} options={{ title: '' }} />

      <Stack.Screen name="OfficeDetail" component={OfficeDetailScreen} options={{ title: 'Office Details' }} />
      <Stack.Screen name="AppointmentBooking" component={AppointmentBookingScreen} options={{ title: 'Book Appointment' }} />

      <Stack.Screen
        name="NewServiceRequest"
        component={NewServiceRequestScreen}
        options={{ presentation: 'modal', title: 'Apply for Service' }}
      />
      <Stack.Screen name="ServiceRequestDetail" component={ServiceRequestDetailScreen} options={{ title: 'Request Details' }} />
      <Stack.Screen name="MyServiceRequests" component={MyServiceRequestsScreen} options={{ title: 'My Requests' }} />
      <Stack.Screen name="PublicWorks" component={PublicWorksScreen} options={{ title: 'Public Works' }} />

      <Stack.Screen name="NewReport" component={NewReportScreen} options={{ presentation: 'modal', title: 'Report an Issue' }} />
      <Stack.Screen name="ReportDetail" component={ReportDetailScreen} options={{ title: 'Report Details' }} />
      <Stack.Screen name="TrackReport" component={TrackReportScreen} options={{ presentation: 'modal', title: 'Track Report' }} />
      <Stack.Screen name="AllAnnouncements" component={AllAnnouncementsScreen} options={{ title: 'Announcements' }} />
      <Stack.Screen name="AnnouncementDetail" component={AnnouncementDetailScreen} options={{ title: '' }} />
      <Stack.Screen name="AllAlerts" component={AllAlertsScreen} options={{ title: 'Emergency Alerts' }} />

      <Stack.Screen name="Emergency" component={EmergencyScreen} options={{ presentation: 'modal', title: 'Emergency' }} />
      <Stack.Screen name="ShelterList" component={ShelterListScreen} options={{ title: 'Shelters' }} />
      <Stack.Screen name="Checklist" component={ChecklistScreen} options={{ title: 'Emergency Checklist' }} />
      <Stack.Screen name="OfflineGuide" component={OfflineGuideScreen} options={{ title: 'Offline Survival Guide' }} />
      <Stack.Screen name="EmergencyContacts" component={EmergencyContactsScreen} options={{ title: 'Emergency Contacts' }} />
    </Stack.Navigator>
  );
}

export default function App() {
  return (
    <AppProvider>
      <NavigationContainer>
        <StatusBar style="dark" />
        <RootNavigator />
      </NavigationContainer>
    </AppProvider>
  );
}
