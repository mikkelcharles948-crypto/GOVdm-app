import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { GovPalette } from '../theme/theme';

import HomeScreen from '../screens/HomeScreen';
import OfficeDirectoryScreen from '../screens/OfficeDirectoryScreen';
import ServicesScreen from '../screens/ServiceScreens';
import DisasterScreen from '../screens/DisasterScreens';
import MoreScreen from '../screens/MoreScreen';

const Tab = createBottomTabNavigator();

const tabIcon = (name) => ({ color, size }) => <Ionicons name={name} size={size} color={color} />;

export default function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: GovPalette.jungle,
        tabBarInactiveTintColor: '#8E8E93',
      }}
    >
      <Tab.Screen
        name="HomeTab"
        component={HomeScreen}
        options={{ title: 'Home', tabBarIcon: tabIcon('home') }}
      />
      <Tab.Screen
        name="DirectoryTab"
        component={OfficeDirectoryScreen}
        options={{ title: 'Directory', tabBarIcon: tabIcon('business') }}
      />
      <Tab.Screen
        name="ServicesTab"
        component={ServicesScreen}
        options={{ title: 'Services', tabBarIcon: tabIcon('laptop-outline') }}
      />
      <Tab.Screen
        name="DisasterTab"
        component={DisasterScreen}
        options={{ title: 'Disaster', tabBarIcon: tabIcon('thunderstorm') }}
      />
      <Tab.Screen
        name="MoreTab"
        component={MoreScreen}
        options={{ title: 'More', tabBarIcon: tabIcon('menu') }}
      />
    </Tab.Navigator>
  );
}
