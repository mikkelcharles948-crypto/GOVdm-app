import React from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, useColorScheme } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { GovPalette, SystemColors, Spacing, Radius, FontSize } from '../theme/theme';
import { ReportStatusInfo } from '../data/enums';

// MARK: - useSystemColors
// Small helper hook standing in for SwiftUI's Color(.secondarySystemBackground) etc.
export function useSystemColors() {
  const scheme = useColorScheme();
  return SystemColors[scheme === 'dark' ? 'dark' : 'light'];
}

// MARK: - GovCard
// A rounded card with soft shadow — the primary container style.
export function GovCard({ children, style, padding = 16 }) {
  const sc = useSystemColors();
  return (
    <View
      style={[
        styles.card,
        { backgroundColor: sc.secondaryBackground, padding, borderRadius: Radius.xl },
        style,
      ]}
    >
      {children}
    </View>
  );
}

// MARK: - GovSectionHeader
export function GovSectionHeader({ title, actionTitle, onAction }) {
  return (
    <View style={styles.sectionHeaderRow}>
      <Text style={styles.sectionHeaderTitle}>{title}</Text>
      <View style={{ flex: 1 }} />
      {actionTitle ? (
        <TouchableOpacity onPress={onAction}>
          <Text style={styles.sectionHeaderAction}>{actionTitle}</Text>
        </TouchableOpacity>
      ) : null}
    </View>
  );
}

// MARK: - GovPill
export function GovPill({ text, color = GovPalette.jungle }) {
  return (
    <View style={[styles.pill, { backgroundColor: withAlpha(color, 0.14) }]}>
      <Text style={[styles.pillText, { color }]} numberOfLines={1}>
        {text}
      </Text>
    </View>
  );
}

// MARK: - GovStatusBadge
export function GovStatusBadge({ status }) {
  const info = ReportStatusInfo[status] || ReportStatusInfo.submitted;
  return (
    <View style={[styles.statusBadge, { backgroundColor: info.color }]}>
      <Text style={styles.statusBadgeText}>{info.displayName}</Text>
    </View>
  );
}

// MARK: - GovSearchBar
export function GovSearchBar({ value, onChangeText, placeholder = 'Search...' }) {
  const sc = useSystemColors();
  return (
    <View style={[styles.searchBar, { backgroundColor: sc.tertiaryBackground }]}>
      <Ionicons name="search" size={16} color={sc.secondaryLabel} />
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={sc.secondaryLabel}
        style={[styles.searchInput, { color: sc.label }]}
        autoCapitalize="none"
      />
      {value?.length > 0 && (
        <TouchableOpacity onPress={() => onChangeText('')}>
          <Ionicons name="close-circle" size={16} color={sc.secondaryLabel} />
        </TouchableOpacity>
      )}
    </View>
  );
}

// MARK: - GovQuickActionTile (Home quick-actions grid)
export function GovQuickActionTile({ icon, title, color, onPress }) {
  const sc = useSystemColors();
  return (
    <TouchableOpacity
      style={[styles.quickTile, { backgroundColor: sc.secondaryBackground }]}
      onPress={onPress}
      activeOpacity={0.7}
    >
      <View style={[styles.quickTileIconWrap, { backgroundColor: withAlpha(color, 0.12) }]}>
        <Ionicons name={icon} size={22} color={color} />
      </View>
      <Text style={styles.quickTileTitle} numberOfLines={2}>
        {title}
      </Text>
    </TouchableOpacity>
  );
}

// MARK: - GovEmergencyButton
export function GovEmergencyButton({ onPress }) {
  return (
    <TouchableOpacity style={styles.emergencyButton} onPress={onPress} activeOpacity={0.85}>
      <Ionicons name="alert-circle" size={26} color="#FFFFFF" />
      <View style={{ marginLeft: 12, flex: 1 }}>
        <Text style={styles.emergencyButtonTitle}>Emergency Assistance</Text>
        <Text style={styles.emergencyButtonSubtitle}>Tap for police, fire & disaster hotlines</Text>
      </View>
      <Ionicons name="chevron-forward" size={18} color="#FFFFFF" />
    </TouchableOpacity>
  );
}

// MARK: - GovEmptyState
export function GovEmptyState({ icon, title, message }) {
  return (
    <View style={styles.emptyState}>
      <Ionicons name={icon} size={40} color="#8E8E93" />
      <Text style={styles.emptyStateTitle}>{title}</Text>
      <Text style={styles.emptyStateMessage}>{message}</Text>
    </View>
  );
}

// MARK: - GovFlagHeader
export function GovFlagHeader() {
  return (
    <View style={styles.flagHeader}>
      <View style={styles.flagCircle}>
        <Ionicons name="shield-checkmark" size={18} color={GovPalette.gold} />
      </View>
    </View>
  );
}

// MARK: - GovFormField
export function GovFormField({ label, value, onChangeText, placeholder, keyboardType, autoCapitalize }) {
  const sc = useSystemColors();
  return (
    <View style={{ gap: 8 }}>
      <Text style={styles.formLabel}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={sc.secondaryLabel}
        keyboardType={keyboardType}
        autoCapitalize={autoCapitalize ?? 'sentences'}
        style={[styles.formInput, { backgroundColor: sc.tertiaryBackground, color: sc.label }]}
      />
    </View>
  );
}

// MARK: - FlowLayout equivalent (simple wrapping row, used for tag chips)
export function FlowLayout({ children, spacing = 8 }) {
  return <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing }}>{children}</View>;
}

// MARK: - PrimaryButton / SecondaryButton (repeated pattern across screens)
export function PrimaryButton({ title, icon, onPress, disabled, color = GovPalette.jungle }) {
  return (
    <TouchableOpacity
      style={[styles.primaryButton, { backgroundColor: disabled ? '#9AA0A6' : color }]}
      onPress={onPress}
      disabled={disabled}
      activeOpacity={0.85}
    >
      {icon ? <Ionicons name={icon} size={18} color="#fff" style={{ marginRight: 8 }} /> : null}
      <Text style={styles.primaryButtonText}>{title}</Text>
    </TouchableOpacity>
  );
}

export function SoftButton({ title, icon, onPress, color = GovPalette.jungle, textColor }) {
  return (
    <TouchableOpacity
      style={[styles.softButton, { backgroundColor: withAlpha(color, 0.12) }]}
      onPress={onPress}
      activeOpacity={0.85}
    >
      {icon ? <Ionicons name={icon} size={18} color={textColor ?? color} style={{ marginRight: 8 }} /> : null}
      <Text style={[styles.primaryButtonText, { color: textColor ?? color }]}>{title}</Text>
    </TouchableOpacity>
  );
}

export function InfoRow({ label, value }) {
  return (
    <View style={styles.infoRow}>
      <Text style={styles.infoRowLabel}>{label}</Text>
      <Text style={styles.infoRowValue} numberOfLines={3}>
        {value}
      </Text>
    </View>
  );
}

export function FilterChip({ title, isSelected, onPress }) {
  const sc = useSystemColors();
  return (
    <TouchableOpacity
      onPress={onPress}
      style={[
        styles.filterChip,
        { backgroundColor: isSelected ? GovPalette.jungle : sc.tertiaryBackground },
      ]}
    >
      <Text style={[styles.filterChipText, { color: isSelected ? '#fff' : sc.label }]}>{title}</Text>
    </TouchableOpacity>
  );
}

// Helper to approximate SwiftUI's `.opacity()` on a hex color.
export function withAlpha(hexColor, alpha) {
  const hex = hexColor.replace('#', '');
  const r = parseInt(hex.substring(0, 2), 16);
  const g = parseInt(hex.substring(2, 4), 16);
  const b = parseInt(hex.substring(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

const styles = StyleSheet.create({
  card: {
    shadowColor: '#000',
    shadowOpacity: 0.04,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
    elevation: 1,
  },
  sectionHeaderRow: { flexDirection: 'row', alignItems: 'center' },
  sectionHeaderTitle: { fontSize: FontSize.title3, fontWeight: '700', color: undefined },
  sectionHeaderAction: { fontSize: FontSize.callout, fontWeight: '600', color: GovPalette.gold },
  pill: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: Radius.pill,
    alignSelf: 'flex-start',
  },
  pillText: { fontSize: FontSize.sm, fontWeight: '600' },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: Radius.pill,
    alignSelf: 'flex-start',
  },
  statusBadgeText: { color: '#fff', fontSize: FontSize.body, fontWeight: '700' },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: Radius.md,
    paddingHorizontal: 14,
    paddingVertical: 12,
    gap: 8,
  },
  searchInput: { flex: 1, fontSize: FontSize.headline },
  quickTile: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 14,
    borderRadius: Radius.xl,
    shadowColor: '#000',
    shadowOpacity: 0.04,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
    elevation: 1,
  },
  quickTileIconWrap: {
    width: 48,
    height: 48,
    borderRadius: Radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  quickTileTitle: { fontSize: FontSize.body, fontWeight: '500', textAlign: 'center', color: '#1C1C1E' },
  emergencyButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: GovPalette.emergency,
    borderRadius: Radius.xl,
    padding: 16,
  },
  emergencyButtonTitle: { color: '#fff', fontSize: FontSize.headline, fontWeight: '700' },
  emergencyButtonSubtitle: { color: 'rgba(255,255,255,0.85)', fontSize: FontSize.caption, marginTop: 2 },
  emptyState: { alignItems: 'center', paddingVertical: 40, gap: 8 },
  emptyStateTitle: { fontSize: FontSize.headline, fontWeight: '600', color: '#1C1C1E' },
  emptyStateMessage: { fontSize: FontSize.body, color: '#6C6C70', textAlign: 'center', paddingHorizontal: 24 },
  flagHeader: { alignItems: 'center', justifyContent: 'center' },
  flagCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: GovPalette.jungle,
    alignItems: 'center',
    justifyContent: 'center',
  },
  formLabel: { fontSize: FontSize.callout, fontWeight: '500', color: '#6C6C70' },
  formInput: { fontSize: FontSize.headline, padding: 14, borderRadius: Radius.md },
  primaryButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderRadius: Radius.lg,
  },
  primaryButtonText: { color: '#fff', fontSize: FontSize.headline, fontWeight: '700' },
  softButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 15,
    borderRadius: Radius.lg,
  },
  infoRow: { flexDirection: 'row', justifyContent: 'space-between', gap: 12 },
  infoRowLabel: { fontSize: FontSize.callout, color: '#6C6C70' },
  infoRowValue: { fontSize: FontSize.callout, fontWeight: '500', color: '#1C1C1E', flexShrink: 1, textAlign: 'right' },
  filterChip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: Radius.pill },
  filterChipText: { fontSize: FontSize.body, fontWeight: '500' },
});

export const Divider = () => {
  const sc = useSystemColors();
  return <View style={{ height: StyleSheet.hairlineWidth, backgroundColor: sc.separator }} />;
};
