import React from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../state/AppContext';
import { GovPalette, FontSize, Radius } from '../theme/theme';
import {
  GovCard,
  GovSectionHeader,
  GovPill,
  GovStatusBadge,
  GovQuickActionTile,
  GovEmergencyButton,
  GovFlagHeader,
  useSystemColors,
} from '../components/GovComponents';
import { AlertTypeInfo, AlertSeverityInfo, AnnouncementPriorityInfo, ReportCategoryInfo, TourismCategoryInfo } from '../data/enums';

function greetingText() {
  const hour = new Date().getHours();
  if (hour >= 5 && hour < 12) return 'Good morning';
  if (hour >= 12 && hour < 17) return 'Good afternoon';
  if (hour >= 17 && hour < 22) return 'Good evening';
  return 'Welcome';
}

export default function HomeScreen({ navigation }) {
  const { isLoggedIn, currentUser, emergencyAlerts, announcements, reports, tourismSites } = useApp();
  const activeAlerts = emergencyAlerts.filter((a) => a.isActive);

  return (
    <View style={{ flex: 1, backgroundColor: '#fff' }}>
      <View style={styles.topBar}>
        <View style={styles.logoRow}>
          <View style={styles.logoCircle}>
            <Ionicons name="shield-checkmark" size={16} color={GovPalette.gold} />
          </View>
          <Text style={styles.logoText}>GovDM</Text>
        </View>
        <TouchableOpacity onPress={() => navigation.navigate('Settings')}>
          <Ionicons name="person-circle" size={30} color={GovPalette.jungle} />
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Header greeting */}
        <View style={{ marginBottom: 4 }}>
          <Text style={styles.greeting}>{greetingText()}</Text>
          <Text style={styles.userName}>{isLoggedIn ? currentUser.name : 'Welcome to GovDM'}</Text>
          <View style={styles.locationRow}>
            <Ionicons name="location" size={12} color={GovPalette.gold} />
            <Text style={styles.locationText}>Commonwealth of Dominica</Text>
          </View>
        </View>

        {/* Active alerts */}
        {activeAlerts.length > 0 && (
          <View style={styles.section}>
            <GovSectionHeader
              title="Active Alerts"
              actionTitle="See all"
              onAction={() => navigation.navigate('AllAlerts')}
            />
            {activeAlerts.slice(0, 3).map((alert) => (
              <EmergencyAlertCard key={alert.id} alert={alert} />
            ))}
          </View>
        )}

        {/* Emergency button */}
        <GovEmergencyButton onPress={() => navigation.navigate('Emergency')} />

        {/* Quick actions */}
        <View style={styles.section}>
          <GovSectionHeader title="Quick Actions" />
          <View style={styles.quickGrid}>
            <GovQuickActionTile
              icon="chatbubble-ellipses"
              title="Report Issue"
              color={GovPalette.emergency}
              onPress={() => navigation.navigate('NewReport')}
            />
            <GovQuickActionTile
              icon="laptop-outline"
              title="Apply for Service"
              color={GovPalette.info}
              onPress={() => navigation.navigate('NewServiceRequest')}
            />
            <GovQuickActionTile
              icon="search"
              title="Search"
              color={GovPalette.jungle}
              onPress={() => navigation.navigate('Search')}
            />
          </View>
          <View style={styles.quickGrid}>
            <GovQuickActionTile
              icon="business"
              title="Directory"
              color={GovPalette.gold}
              onPress={() => navigation.navigate('DirectoryTab')}
            />
            <GovQuickActionTile
              icon="thunderstorm"
              title="Disaster"
              color={GovPalette.emergency}
              onPress={() => navigation.navigate('DisasterTab')}
            />
            <GovQuickActionTile
              icon="medkit"
              title="Health"
              color={GovPalette.safe}
              onPress={() => navigation.navigate('Health')}
            />
          </View>
        </View>

        {/* Announcements */}
        <View style={styles.section}>
          <GovSectionHeader
            title="Government Announcements"
            actionTitle="See all"
            onAction={() => navigation.navigate('AllAnnouncements')}
          />
          {announcements.slice(0, 3).map((a) => (
            <TouchableOpacity key={a.id} onPress={() => navigation.navigate('AnnouncementDetail', { announcement: a })}>
              <AnnouncementCard announcement={a} />
            </TouchableOpacity>
          ))}
        </View>

        {/* Recent reports */}
        {isLoggedIn && (
          <View style={styles.section}>
            <GovSectionHeader title="Your Reports" />
            {reports.length === 0 ? (
              <GovCard>
                <View style={{ alignItems: 'center', gap: 6, paddingVertical: 6 }}>
                  <Ionicons name="document-text-outline" size={30} color="#8E8E93" />
                  <Text style={{ fontSize: FontSize.headline, fontWeight: '500' }}>No reports yet</Text>
                  <Text style={{ fontSize: FontSize.body, color: '#6C6C70' }}>
                    Submit a report to track its status here.
                  </Text>
                </View>
              </GovCard>
            ) : (
              reports.slice(0, 2).map((r) => (
                <TouchableOpacity key={r.id} onPress={() => navigation.navigate('ReportDetail', { report: r })}>
                  <ReportCard report={r} />
                </TouchableOpacity>
              ))
            )}
          </View>
        )}

        {/* Discover teaser */}
        <View style={styles.section}>
          <GovSectionHeader title="Discover Dominica" />
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View style={{ flexDirection: 'row', gap: 12 }}>
              {tourismSites.slice(0, 6).map((site) => (
                <TouchableOpacity key={site.id} onPress={() => navigation.navigate('TourismSiteDetail', { site })}>
                  <TourismTeaserCard site={site} />
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>
        </View>

        {/* Footer */}
        <View style={styles.footer}>
          <GovFlagHeader />
          <Text style={styles.footerTitle}>Government of the Commonwealth of Dominica</Text>
          <Text style={styles.footerSub}>Digital Citizen Services Platform</Text>
          <Text style={styles.footerVersion}>v1.0.0</Text>
        </View>
      </ScrollView>
    </View>
  );
}

export function EmergencyAlertCard({ alert }) {
  const typeInfo = AlertTypeInfo[alert.type] || AlertTypeInfo.hurricane;
  const sevInfo = AlertSeverityInfo[alert.severity] || AlertSeverityInfo.watch;
  return (
    <View style={[styles.alertCard, { backgroundColor: `${sevInfo.color}14`, borderColor: `${sevInfo.color}33` }]}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <Ionicons name={typeInfo.icon} size={20} color={sevInfo.color} />
        <View style={{ flex: 1 }}>
          <Text style={styles.alertType}>{typeInfo.displayName}</Text>
          <Text style={styles.alertTitle} numberOfLines={2}>
            {alert.title}
          </Text>
        </View>
        <GovPill text={sevInfo.displayName} color={sevInfo.color} />
      </View>
      <Text style={styles.alertMessage} numberOfLines={3}>
        {alert.message}
      </Text>
    </View>
  );
}

export function AnnouncementCard({ announcement }) {
  const info = AnnouncementPriorityInfo[announcement.priority] || AnnouncementPriorityInfo.normal;
  return (
    <GovCard style={{ marginBottom: 12 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 }}>
        <Ionicons name={info.icon} size={18} color={info.color} />
        <Text style={styles.announcementDept} numberOfLines={1}>
          {announcement.department}
        </Text>
        <View style={{ flex: 1 }} />
        <GovPill text={info.displayName} color={info.color} />
      </View>
      <Text style={styles.announcementTitle} numberOfLines={2}>
        {announcement.title}
      </Text>
      <Text style={styles.announcementSummary} numberOfLines={2}>
        {announcement.summary}
      </Text>
      <Text style={styles.announcementDate}>{new Date(announcement.date).toLocaleDateString()}</Text>
    </GovCard>
  );
}

export function ReportCard({ report }) {
  const catInfo = ReportCategoryInfo[report.category] || ReportCategoryInfo.other;
  return (
    <GovCard style={{ marginBottom: 12 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 10 }}>
        <View style={[styles.catIconWrap, { backgroundColor: `${catInfo.color}1A` }]}>
          <Ionicons name={catInfo.icon} size={18} color={catInfo.color} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.reportTitle} numberOfLines={1}>
            {report.title}
          </Text>
          <Text style={styles.reportCode}>{report.trackingCode}</Text>
        </View>
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <GovStatusBadge status={report.status} />
        <View style={{ flex: 1 }} />
        <Text style={styles.reportDate}>{new Date(report.createdAt).toLocaleDateString()}</Text>
      </View>
    </GovCard>
  );
}

export function TourismTeaserCard({ site }) {
  const catInfo = TourismCategoryInfo[site.category];
  return (
    <View style={styles.teaserCard}>
      <LinearGradient colors={[GovPalette.jungle, GovPalette.jungleLight, GovPalette.ocean]} style={styles.teaserImage}>
        <Ionicons name={catInfo?.icon || 'leaf'} size={30} color="rgba(255,255,255,0.85)" />
      </LinearGradient>
      <View style={{ padding: 10 }}>
        <Text style={styles.teaserTitle} numberOfLines={1}>
          {site.name}
        </Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 4 }}>
          <Ionicons name="star" size={10} color={GovPalette.gold} />
          <Text style={styles.teaserRating}>{site.rating.toFixed(1)}</Text>
          <Text style={{ color: '#6C6C70' }}>•</Text>
          <Text style={styles.teaserParish}>{site.parish}</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingTop: 8,
    paddingBottom: 4,
  },
  logoRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  logoCircle: { width: 32, height: 32, borderRadius: 16, backgroundColor: GovPalette.jungle, alignItems: 'center', justifyContent: 'center' },
  logoText: { fontSize: FontSize.headline, fontWeight: '700', color: GovPalette.jungle },
  scrollContent: { padding: 16, paddingBottom: 32, gap: 4 },
  greeting: { fontSize: FontSize.subheadline, color: '#6C6C70' },
  userName: { fontSize: FontSize.largeTitle, fontWeight: '700', color: '#1C1C1E', marginTop: 2 },
  locationRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 4 },
  locationText: { fontSize: FontSize.body, fontWeight: '500', color: GovPalette.gold },
  section: { marginTop: 20, gap: 12 },
  quickGrid: { flexDirection: 'row', gap: 12, marginBottom: 12 },
  alertCard: { borderRadius: Radius.lg, borderWidth: 1, padding: 14, marginBottom: 12, gap: 10 },
  alertType: { fontSize: FontSize.body, fontWeight: '500', color: '#6C6C70' },
  alertTitle: { fontSize: FontSize.subheadline, fontWeight: '700', color: '#1C1C1E', marginTop: 2 },
  alertMessage: { fontSize: FontSize.body, color: '#6C6C70' },
  announcementDept: { fontSize: FontSize.sm, fontWeight: '500', color: '#6C6C70', flexShrink: 1 },
  announcementTitle: { fontSize: FontSize.headline, fontWeight: '700', color: '#1C1C1E', marginBottom: 6 },
  announcementSummary: { fontSize: FontSize.body, color: '#6C6C70', marginBottom: 6 },
  announcementDate: { fontSize: FontSize.sm, color: '#8E8E93' },
  catIconWrap: { width: 40, height: 40, borderRadius: Radius.sm, alignItems: 'center', justifyContent: 'center' },
  reportTitle: { fontSize: FontSize.subheadline, fontWeight: '600', color: '#1C1C1E' },
  reportCode: { fontSize: FontSize.caption, fontWeight: '500', color: '#6C6C70', marginTop: 2 },
  reportDate: { fontSize: FontSize.sm, color: '#8E8E93' },
  teaserCard: { width: 180, backgroundColor: '#F2F2F7', borderRadius: Radius.lg, overflow: 'hidden' },
  teaserImage: { width: 180, height: 110, alignItems: 'center', justifyContent: 'center' },
  teaserTitle: { fontSize: FontSize.callout, fontWeight: '700', color: '#1C1C1E' },
  teaserRating: { fontSize: FontSize.caption, fontWeight: '500', color: '#1C1C1E' },
  teaserParish: { fontSize: FontSize.caption, color: '#6C6C70' },
  footer: { alignItems: 'center', marginTop: 24, gap: 4 },
  footerTitle: { fontSize: FontSize.caption, fontWeight: '600', color: '#6C6C70' },
  footerSub: { fontSize: FontSize.sm, color: '#8E8E93' },
  footerVersion: { fontSize: FontSize.xs, color: '#AEAEB2', marginTop: 2 },
});
