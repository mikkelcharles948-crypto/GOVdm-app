import React, { useState, useMemo } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Linking } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../state/AppContext';
import { GovPalette, FontSize, Radius } from '../theme/theme';
import { GovCard, GovSearchBar, GovPill, GovEmptyState, FilterChip, InfoRow, Divider, SoftButton } from '../components/GovComponents';
import { TourismCategoryList, TourismCategoryInfo } from '../data/enums';

export default function TourismScreen({ navigation }) {
  const { tourismSites } = useApp();
  const [category, setCategory] = useState(null);
  const [search, setSearch] = useState('');

  const filtered = useMemo(
    () =>
      tourismSites.filter((site) => {
        const matchesSearch =
          !search ||
          site.name.toLowerCase().includes(search.toLowerCase()) ||
          site.description.toLowerCase().includes(search.toLowerCase());
        const matchesCategory = !category || site.category === category;
        return matchesSearch && matchesCategory;
      }),
    [tourismSites, search, category]
  );

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={styles.content}>
      <LinearGradient colors={[GovPalette.jungle, GovPalette.jungleLight, GovPalette.ocean]} style={styles.hero}>
        <Ionicons name="leaf" size={36} color="rgba(255,255,255,0.9)" />
        <Text style={styles.heroTitle}>The Nature Island</Text>
        <Text style={styles.heroDesc}>
          Explore Dominica's pristine rainforests,{'\n'}volcanic wonders & Caribbean coastlines
        </Text>
      </LinearGradient>

      <View style={{ height: 16 }} />
      <GovSearchBar value={search} onChangeText={setSearch} placeholder="Search attractions, sites..." />

      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginVertical: 12 }}>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <FilterChip title="All" isSelected={!category} onPress={() => setCategory(null)} />
          {TourismCategoryList.map((c) => (
            <FilterChip
              key={c}
              title={TourismCategoryInfo[c].displayName}
              isSelected={category === c}
              onPress={() => setCategory(c)}
            />
          ))}
        </View>
      </ScrollView>

      <GovCard style={{ marginBottom: 16 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <Ionicons name="call" size={22} color={GovPalette.emergency} />
          <View style={{ flex: 1 }}>
            <Text style={styles.cardHeading}>Tourist Emergency Assistance</Text>
            <Text style={styles.cardSub}>24/7 support for visitors</Text>
          </View>
          <TouchableOpacity style={styles.callButton} onPress={() => Linking.openURL('tel:+17674482450')}>
            <Text style={styles.callButtonText}>Call</Text>
          </TouchableOpacity>
        </View>
      </GovCard>

      {filtered.length === 0 ? (
        <GovEmptyState icon="map-outline" title="No Sites Found" message="Try adjusting your search or category filter." />
      ) : (
        filtered.map((site) => (
          <TouchableOpacity key={site.id} onPress={() => navigation.navigate('TourismSiteDetail', { site })}>
            <TourismSiteCard site={site} />
          </TouchableOpacity>
        ))
      )}
    </ScrollView>
  );
}

export function TourismSiteCard({ site }) {
  const info = TourismCategoryInfo[site.category];
  const isBeach = site.category === 'beach';
  return (
    <View style={styles.siteCard}>
      <LinearGradient
        colors={isBeach ? [GovPalette.ocean, `${GovPalette.ocean}B3`] : [GovPalette.jungle, GovPalette.jungleLight]}
        style={styles.siteImage}
      >
        <Ionicons name={info.icon} size={36} color="rgba(255,255,255,0.6)" />
        <View style={styles.ratingBadge}>
          <Ionicons name="star" size={10} color={GovPalette.gold} />
          <Text style={styles.ratingText}>{site.rating.toFixed(1)}</Text>
        </View>
      </LinearGradient>
      <View style={{ padding: 14 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Text style={styles.siteName} numberOfLines={1}>
            {site.name}
          </Text>
          <View style={{ flex: 1 }} />
          <GovPill text={info.displayName} color={GovPalette.jungle} />
        </View>
        <Text style={styles.siteDesc} numberOfLines={2}>
          {site.description}
        </Text>
        <View style={{ flexDirection: 'row', gap: 12, marginTop: 6 }}>
          <View style={styles.metaRow}>
            <Ionicons name="location" size={12} color="#6C6C70" />
            <Text style={styles.metaText}>{site.parish}</Text>
          </View>
          <View style={styles.metaRow}>
            <Ionicons name="cash-outline" size={12} color="#6C6C70" />
            <Text style={styles.metaText}>{site.entryFee}</Text>
          </View>
        </View>
      </View>
    </View>
  );
}

export function TourismSiteDetailScreen({ route }) {
  const { site } = route.params;
  const info = TourismCategoryInfo[site.category];
  const isBeach = site.category === 'beach';

  const openMaps = () => {
    const q = encodeURIComponent(site.name);
    Linking.openURL(`https://maps.google.com/?q=${q}&ll=${site.latitude},${site.longitude}`);
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={styles.content}>
      <LinearGradient
        colors={isBeach ? [GovPalette.ocean, `${GovPalette.ocean}99`] : [GovPalette.jungle, GovPalette.jungleLight]}
        style={styles.detailHero}
      >
        <Ionicons name={info.icon} size={48} color="rgba(255,255,255,0.8)" />
        <Text style={styles.detailHeroTitle}>{site.name}</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <Ionicons name="star" size={14} color={GovPalette.gold} />
          <Text style={styles.detailHeroRating}>{site.rating.toFixed(1)}</Text>
        </View>
      </LinearGradient>

      <GovCard style={{ marginTop: 16 }}>
        <Text style={styles.cardHeadingLg}>About</Text>
        <View style={{ height: 8 }} />
        <Text style={styles.aboutText}>{site.description}</Text>
      </GovCard>

      <GovCard style={{ marginTop: 16 }}>
        <Text style={styles.cardHeadingLg}>Information</Text>
        <View style={{ height: 12 }} />
        <InfoRow label="Category" value={info.displayName} />
        <Divider />
        <View style={{ height: 12 }} />
        <InfoRow label="Parish" value={site.parish} />
        <Divider />
        <View style={{ height: 12 }} />
        <InfoRow label="Entry Fee" value={site.entryFee} />
        <Divider />
        <View style={{ height: 12 }} />
        <InfoRow label="Rating" value={`${site.rating.toFixed(1)} / 5.0`} />
      </GovCard>

      {site.tips?.length > 0 && (
        <GovCard style={{ marginTop: 16 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 }}>
            <Ionicons name="bulb" size={18} color={GovPalette.gold} />
            <Text style={styles.cardHeadingLg}>Visitor Tips</Text>
          </View>
          {site.tips.map((tip) => (
            <View key={tip} style={styles.tipRow}>
              <Ionicons name="checkmark-circle" size={14} color={GovPalette.safe} />
              <Text style={styles.tipText}>{tip}</Text>
            </View>
          ))}
        </GovCard>
      )}

      <View style={{ marginTop: 16, marginBottom: 8 }}>
        <SoftButton title="Get Directions" icon="navigate" onPress={openMaps} color={GovPalette.gold} textColor={GovPalette.jungle} />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  content: { padding: 16, paddingBottom: 32 },
  hero: { alignItems: 'center', paddingVertical: 28, borderRadius: Radius.xxl, gap: 8 },
  heroTitle: { fontSize: FontSize.title1, fontWeight: '700', color: '#fff' },
  heroDesc: { fontSize: FontSize.body, color: 'rgba(255,255,255,0.8)', textAlign: 'center' },
  cardHeading: { fontSize: FontSize.callout, fontWeight: '700', color: '#1C1C1E' },
  cardHeadingLg: { fontSize: FontSize.title3, fontWeight: '700', color: '#1C1C1E' },
  cardSub: { fontSize: FontSize.caption, color: '#6C6C70', marginTop: 2 },
  callButton: { backgroundColor: GovPalette.emergency, paddingHorizontal: 16, paddingVertical: 8, borderRadius: Radius.pill },
  callButtonText: { color: '#fff', fontWeight: '700', fontSize: FontSize.body },
  siteCard: { backgroundColor: '#F2F2F7', borderRadius: Radius.xl, overflow: 'hidden', marginBottom: 16 },
  siteImage: { height: 130, alignItems: 'center', justifyContent: 'center' },
  ratingBadge: {
    position: 'absolute',
    top: 10,
    right: 10,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(0,0,0,0.3)',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: Radius.pill,
  },
  ratingText: { color: '#fff', fontSize: FontSize.caption, fontWeight: '700' },
  siteName: { fontSize: FontSize.headline, fontWeight: '700', color: '#1C1C1E', flexShrink: 1 },
  siteDesc: { fontSize: FontSize.body, color: '#6C6C70', marginTop: 6 },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  metaText: { fontSize: FontSize.caption, color: '#6C6C70' },
  detailHero: { alignItems: 'center', paddingVertical: 32, borderRadius: Radius.xxl, gap: 10 },
  detailHeroTitle: { fontSize: FontSize.title1, fontWeight: '700', color: '#fff', textAlign: 'center' },
  detailHeroRating: { fontSize: FontSize.headline, fontWeight: '700', color: '#fff' },
  aboutText: { fontSize: FontSize.subheadline, color: '#6C6C70' },
  tipRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 6 },
  tipText: { fontSize: FontSize.callout, color: '#1C1C1E', flexShrink: 1 },
});
