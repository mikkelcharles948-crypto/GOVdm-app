import React, { useState } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, TextInput, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../state/AppContext';
import { GovPalette, FontSize, Radius } from '../theme/theme';
import {
  GovCard,
  GovStatusBadge,
  GovPill,
  GovEmptyState,
  GovFormField,
  GovSearchBar,
  PrimaryButton,
  FilterChip,
  withAlpha,
} from '../components/GovComponents';
import { AnnouncementCard, EmergencyAlertCard } from './HomeScreen';
import { ReportCategoryList, ReportCategoryInfo, ReportStatus, ReportStatusInfo, AnnouncementPriorityList, AnnouncementPriorityInfo, AlertTypeInfo, AlertSeverityInfo } from '../data/enums';

const StatusOrder = [
  ReportStatus.submitted,
  ReportStatus.received,
  ReportStatus.assigned,
  ReportStatus.inProgress,
  ReportStatus.resolved,
];

export function NewReportScreen({ navigation }) {
  const { submitReport, isGuest } = useApp();
  const [category, setCategory] = useState('roadDamage');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [address, setAddress] = useState('');
  const [reporterName, setReporterName] = useState('');
  const [reporterContact, setReporterContact] = useState('');
  const [anonymous, setAnonymous] = useState(isGuest);

  const submit = () => {
    if (!title || !description) {
      Alert.alert('Missing information', 'Please add a title and description.');
      return;
    }
    if (!anonymous && (!reporterName || !reporterContact)) {
      Alert.alert('Missing information', 'Add your name and contact, or submit anonymously.');
      return;
    }
    submitReport({
      category,
      title,
      description,
      address,
      isAnonymous: anonymous,
      reporterName: anonymous ? '' : reporterName,
      reporterContact: anonymous ? '' : reporterContact,
      department: 'Citizen Reports Unit',
    });
    Alert.alert('Report Submitted', 'Thank you for helping improve Dominica. You can track this report from Home.', [
      { text: 'Done', onPress: () => navigation.popToTop() },
    ]);
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={styles.content}>
      <Text style={styles.sectionHeading}>Category</Text>
      <View style={{ height: 10 }} />
      <View style={styles.typeGrid}>
        {ReportCategoryList.map((c) => {
          const info = ReportCategoryInfo[c];
          const selected = category === c;
          return (
            <TouchableOpacity
              key={c}
              style={[styles.typeTile, selected && { backgroundColor: withAlpha(info.color, 0.14), borderColor: info.color }]}
              onPress={() => setCategory(c)}
            >
              <Ionicons name={info.icon} size={20} color={selected ? info.color : '#6C6C70'} />
              <Text style={[styles.typeTileText, selected && { color: info.color, fontWeight: '700' }]}>
                {info.displayName}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>

      <View style={{ height: 20 }} />
      <GovFormField label="Title" value={title} onChangeText={setTitle} placeholder="Brief summary of the issue" />
      <View style={{ height: 16 }} />
      <Text style={styles.formLabel}>Description</Text>
      <View style={{ height: 8 }} />
      <TextInput
        value={description}
        onChangeText={setDescription}
        placeholder="Provide as much detail as possible..."
        multiline
        style={styles.textArea}
      />
      <View style={{ height: 16 }} />
      <GovFormField label="Location / Address" value={address} onChangeText={setAddress} placeholder="e.g. Near the market, Roseau" />

      <View style={{ height: 20 }} />
      <TouchableOpacity style={styles.anonRow} onPress={() => setAnonymous((v) => !v)}>
        <Ionicons name={anonymous ? 'checkbox' : 'square-outline'} size={20} color={anonymous ? GovPalette.jungle : '#8E8E93'} />
        <Text style={styles.anonText}>Submit anonymously</Text>
      </TouchableOpacity>

      {!anonymous && (
        <View style={{ gap: 16, marginTop: 12 }}>
          <GovFormField label="Your Name" value={reporterName} onChangeText={setReporterName} placeholder="Full name" />
          <GovFormField label="Your Contact" value={reporterContact} onChangeText={setReporterContact} placeholder="Phone or email" />
        </View>
      )}

      <View style={{ height: 24 }} />
      <PrimaryButton title="Submit Report" icon="paper-plane" onPress={submit} color={GovPalette.emergency} />
    </ScrollView>
  );
}

export function ReportDetailScreen({ route }) {
  const { report } = route.params;
  const info = ReportCategoryInfo[report.category];
  const currentIdx = StatusOrder.indexOf(report.status);

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={styles.content}>
      <GovCard style={{ marginBottom: 16, alignItems: 'center', paddingVertical: 24 }}>
        <Ionicons name={info.icon} size={40} color={info.color} />
        <Text style={[styles.sectionHeading, { marginTop: 10, textAlign: 'center' }]}>{report.title}</Text>
        <Text style={styles.trackingCode}>{report.trackingCode}</Text>
        <View style={{ height: 10 }} />
        <GovStatusBadge status={report.status} />
      </GovCard>

      <GovCard style={{ marginBottom: 16 }}>
        <Text style={styles.sectionHeading}>Status Timeline</Text>
        <View style={{ height: 12 }} />
        {StatusOrder.map((s, idx) => {
          const isDone = idx <= currentIdx;
          const sInfo = ReportStatusInfo[s];
          return (
            <View key={s} style={styles.timelineRow}>
              <View style={styles.timelineDotColumn}>
                <View style={[styles.timelineDot, { backgroundColor: isDone ? sInfo.color : '#E5E5EA' }]} />
                {idx < StatusOrder.length - 1 && (
                  <View style={[styles.timelineLine, { backgroundColor: idx < currentIdx ? sInfo.color : '#E5E5EA' }]} />
                )}
              </View>
              <Text style={[styles.timelineText, isDone && { fontWeight: '700', color: '#1C1C1E' }]}>
                {sInfo.displayName}
              </Text>
            </View>
          );
        })}
      </GovCard>

      <GovCard style={{ marginBottom: 16 }}>
        <Text style={styles.sectionHeading}>Description</Text>
        <View style={{ height: 8 }} />
        <Text style={styles.description}>{report.description}</Text>
      </GovCard>

      {report.address ? (
        <GovCard>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <Ionicons name="location" size={16} color="#6C6C70" />
            <Text style={styles.description}>{report.address}</Text>
          </View>
        </GovCard>
      ) : null}
    </ScrollView>
  );
}

export function TrackReportScreen({ navigation }) {
  const { reportByTrackingCode } = useApp();
  const [code, setCode] = useState('');
  const [notFound, setNotFound] = useState(false);

  const track = () => {
    const report = reportByTrackingCode(code);
    if (report) {
      setNotFound(false);
      navigation.navigate('ReportDetail', { report });
    } else {
      setNotFound(true);
    }
  };

  return (
    <View style={styles.content}>
      <Text style={styles.sectionHeading}>Track a Report</Text>
      <Text style={styles.trackDesc}>Enter the tracking code you received when you submitted your report.</Text>
      <View style={{ height: 16 }} />
      <GovFormField label="Tracking Code" value={code} onChangeText={setCode} placeholder="e.g. RPT-1234567890" autoCapitalize="characters" />
      {notFound && <Text style={styles.notFoundText}>No report found with that tracking code.</Text>}
      <View style={{ height: 20 }} />
      <PrimaryButton title="Track Report" icon="search" onPress={track} disabled={!code} />
    </View>
  );
}

export function AllAnnouncementsScreen({ navigation }) {
  const { announcements } = useApp();
  const [priority, setPriority] = useState(null);
  const filtered = priority ? announcements.filter((a) => a.priority === priority) : announcements;

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={styles.content}>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 14 }}>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <FilterChip title="All" isSelected={!priority} onPress={() => setPriority(null)} />
          {AnnouncementPriorityList.map((p) => (
            <FilterChip key={p} title={AnnouncementPriorityInfo[p].displayName} isSelected={priority === p} onPress={() => setPriority(p)} />
          ))}
        </View>
      </ScrollView>

      {filtered.length === 0 ? (
        <GovEmptyState icon="megaphone-outline" title="No Announcements" message="Check back later for updates." />
      ) : (
        filtered.map((a) => (
          <TouchableOpacity key={a.id} onPress={() => navigation.navigate('AnnouncementDetail', { announcement: a })}>
            <AnnouncementCard announcement={a} />
          </TouchableOpacity>
        ))
      )}
    </ScrollView>
  );
}

export function AnnouncementDetailScreen({ route }) {
  const { announcement } = route.params;
  const info = AnnouncementPriorityInfo[announcement.priority];
  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={styles.content}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 }}>
        <Ionicons name={info.icon} size={18} color={info.color} />
        <GovPill text={info.displayName} color={info.color} />
        <View style={{ flex: 1 }} />
        <Text style={styles.trackDesc}>{new Date(announcement.date).toLocaleDateString()}</Text>
      </View>
      <Text style={styles.detailTitle}>{announcement.title}</Text>
      <Text style={styles.detailDept}>{announcement.department}</Text>
      <View style={{ height: 16 }} />
      <Text style={styles.description}>{announcement.body}</Text>
      {announcement.tags?.length > 0 && (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 16 }}>
          {announcement.tags.map((t) => (
            <GovPill key={t} text={`#${t}`} color={GovPalette.jungle} />
          ))}
        </View>
      )}
    </ScrollView>
  );
}

export function AllAlertsScreen() {
  const { emergencyAlerts } = useApp();
  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={styles.content}>
      {emergencyAlerts.length === 0 ? (
        <GovEmptyState icon="checkmark-circle-outline" title="No Alerts" message="There are currently no active emergency alerts." />
      ) : (
        emergencyAlerts.map((a) => <EmergencyAlertCard key={a.id} alert={a} />)
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  content: { padding: 16, paddingBottom: 32 },
  sectionHeading: { fontSize: FontSize.title3, fontWeight: '700', color: '#1C1C1E' },
  formLabel: { fontSize: FontSize.callout, fontWeight: '500', color: '#6C6C70' },
  textArea: { minHeight: 100, backgroundColor: '#E5E5EA', borderRadius: Radius.md, padding: 14, fontSize: FontSize.subheadline, textAlignVertical: 'top' },
  typeGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  typeTile: {
    width: '31%',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 14,
    borderRadius: Radius.md,
    borderWidth: 1.5,
    borderColor: '#E5E5EA',
    backgroundColor: '#F9F9F9',
  },
  typeTileText: { fontSize: FontSize.xs, color: '#1C1C1E', textAlign: 'center' },
  anonRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  anonText: { fontSize: FontSize.subheadline, color: '#1C1C1E' },
  trackingCode: { fontSize: FontSize.body, color: '#6C6C70', marginTop: 4 },
  timelineRow: { flexDirection: 'row', gap: 12, minHeight: 40 },
  timelineDotColumn: { alignItems: 'center', width: 16 },
  timelineDot: { width: 14, height: 14, borderRadius: 7 },
  timelineLine: { width: 2, flex: 1, marginTop: 2 },
  timelineText: { fontSize: FontSize.subheadline, color: '#8E8E93', paddingBottom: 16 },
  description: { fontSize: FontSize.subheadline, color: '#3A3A3C', lineHeight: 20 },
  trackDesc: { fontSize: FontSize.body, color: '#6C6C70' },
  notFoundText: { fontSize: FontSize.caption, color: GovPalette.emergency, marginTop: 8 },
  detailTitle: { fontSize: FontSize.title1, fontWeight: '700', color: '#1C1C1E' },
  detailDept: { fontSize: FontSize.body, color: '#6C6C70', marginTop: 4 },
});
