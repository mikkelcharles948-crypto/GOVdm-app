import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Dimensions,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../state/AppContext';
import { GovPalette, FontSize, Radius } from '../theme/theme';
import { GovFormField } from '../components/GovComponents';
import { AppLanguageList, AppLanguageInfo, AllParishes, DefaultParish } from '../data/enums';

const { width } = Dimensions.get('window');

export default function OnboardingScreen({ navigation }) {
  const { language, updateLanguage, loginAsGuest } = useApp();
  const [page, setPage] = useState(0);
  const scrollRef = useRef(null);

  const goTo = (p) => {
    setPage(p);
    scrollRef.current?.scrollTo({ x: p * width, animated: true });
  };

  return (
    <LinearGradient
      colors={[GovPalette.jungleDark, GovPalette.jungle, GovPalette.jungleLight]}
      style={{ flex: 1 }}
    >
      <View style={styles.topRow}>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          {[0, 1, 2].map((i) => (
            <View
              key={i}
              style={[
                styles.dot,
                { width: i === page ? 24 : 8, backgroundColor: i === page ? GovPalette.gold : 'rgba(255,255,255,0.3)' },
              ]}
            />
          ))}
        </View>
        <View style={{ flex: 1 }} />
        {page > 0 && (
          <TouchableOpacity onPress={loginAsGuest}>
            <Text style={styles.skipText}>Skip</Text>
          </TouchableOpacity>
        )}
      </View>

      <ScrollView
        ref={scrollRef}
        horizontal
        pagingEnabled
        scrollEnabled={false}
        showsHorizontalScrollIndicator={false}
        style={{ flex: 1 }}
      >
        <View style={{ width }}>
          <WelcomePage />
        </View>
        <View style={{ width }}>
          <LanguagePage
            language={language}
            updateLanguage={(lang) => {
              updateLanguage(lang);
              goTo(2);
            }}
          />
        </View>
        <View style={{ width }}>
          <FeaturesPage />
        </View>
      </ScrollView>

      <View style={styles.bottomActions}>
        {page < 2 ? (
          <TouchableOpacity style={styles.goldButton} onPress={() => goTo(page + 1)}>
            <Text style={styles.goldButtonText}>{page === 0 ? 'Get Started' : 'Continue'}</Text>
          </TouchableOpacity>
        ) : (
          <View style={{ gap: 12 }}>
            <TouchableOpacity style={styles.goldButton} onPress={() => navigation.navigate('Login')}>
              <Text style={styles.goldButtonText}>Create Citizen Account</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.ghostButton} onPress={loginAsGuest}>
              <Text style={styles.ghostButtonText}>Continue as Guest</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
    </LinearGradient>
  );
}

function WelcomePage() {
  return (
    <View style={styles.pageCenter}>
      <View style={styles.emblem}>
        <Ionicons name="shield-checkmark" size={64} color={GovPalette.gold} />
      </View>
      <Text style={styles.appName}>GovDM</Text>
      <Text style={styles.appSubtitle}>Government of the{'\n'}Commonwealth of Dominica</Text>

      <View style={{ height: 32 }} />

      <Text style={styles.tagline}>Citizen Services, Simplified.</Text>
      <Text style={styles.taglineDesc}>
        Your official digital gateway to government services — report issues, apply for documents, track
        requests, and stay informed during emergencies.
      </Text>
    </View>
  );
}

function LanguagePage({ language, updateLanguage }) {
  return (
    <View style={styles.pageCenter}>
      <Ionicons name="globe-outline" size={44} color={GovPalette.gold} />
      <Text style={styles.pageTitle}>Choose Your Language</Text>
      <Text style={styles.pageDesc}>Select your preferred language. You can change this anytime in Settings.</Text>

      <View style={{ width: '100%', gap: 14, marginTop: 20 }}>
        {AppLanguageList.map((lang) => {
          const info = AppLanguageInfo[lang];
          const selected = language === lang;
          return (
            <TouchableOpacity
              key={lang}
              style={[styles.langRow, selected && styles.langRowSelected]}
              onPress={() => updateLanguage(lang)}
            >
              <View style={styles.langFlag}>
                <Text style={{ color: GovPalette.gold, fontWeight: '700', fontSize: 12 }}>{info.flag}</Text>
              </View>
              <Text style={styles.langName}>{info.displayName}</Text>
              <View style={{ flex: 1 }} />
              {selected && <Ionicons name="checkmark-circle" size={22} color={GovPalette.gold} />}
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
}

function FeaturesPage() {
  const features = [
    { icon: 'chatbubble-ellipses', title: 'Report Issues', desc: 'Anonymous or named reports for crime, corruption, road damage & more' },
    { icon: 'laptop-outline', title: 'Apply for Services', desc: 'Birth certificates, permits, licenses & government services online' },
    { icon: 'thunderstorm-outline', title: 'Disaster Readiness', desc: 'Emergency alerts, shelter locator & offline survival guide' },
    { icon: 'business-outline', title: 'Office Directory', desc: 'Every ministry, council & government office at your fingertips' },
    { icon: 'map-outline', title: 'Discover Dominica', desc: 'Tourism sites, health centres, shelters & essential locations' },
  ];
  return (
    <ScrollView contentContainerStyle={[styles.pageCenter, { paddingTop: 40 }]}>
      <Ionicons name="sparkles-outline" size={44} color={GovPalette.gold} />
      <Text style={styles.pageTitle}>Everything You Need</Text>

      <View style={{ width: '100%', gap: 16, marginTop: 20 }}>
        {features.map((f) => (
          <View key={f.title} style={styles.featureRow}>
            <View style={styles.featureIconWrap}>
              <Ionicons name={f.icon} size={22} color={GovPalette.gold} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.featureTitle}>{f.title}</Text>
              <Text style={styles.featureDesc} numberOfLines={2}>
                {f.desc}
              </Text>
            </View>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

export function LoginScreen({ navigation }) {
  const { loginAsCitizen, completeOnboarding } = useApp();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [parish, setParish] = useState(DefaultParish);

  const submit = () => {
    if (!name || !email || !phone) {
      Alert.alert('Please fill all fields');
      return;
    }
    loginAsCitizen(name, email, phone, parish);
    completeOnboarding();
    navigation.goBack();
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={{ padding: 20, gap: 20 }}>
      <View style={{ alignItems: 'center', gap: 8, marginTop: 12 }}>
        <Ionicons name="shield-checkmark-outline" size={44} color={GovPalette.gold} />
        <Text style={styles.loginTitle}>Create Citizen Account</Text>
        <Text style={styles.loginDesc}>
          Unlock full features — submit & track reports, apply for services, and receive notifications.
        </Text>
      </View>

      <View style={{ gap: 16 }}>
        <GovFormField label="Full Name" value={name} onChangeText={setName} placeholder="John Joseph" />
        <GovFormField
          label="Email"
          value={email}
          onChangeText={setEmail}
          placeholder="you@example.dm"
          keyboardType="email-address"
          autoCapitalize="none"
        />
        <GovFormField
          label="Phone Number"
          value={phone}
          onChangeText={setPhone}
          placeholder="+1 767-XXX-XXXX"
          keyboardType="phone-pad"
        />

        <View style={{ gap: 8 }}>
          <Text style={{ fontSize: FontSize.callout, fontWeight: '500', color: '#6C6C70' }}>Parish</Text>
          <ParishPicker parish={parish} setParish={setParish} />
        </View>
      </View>

      <View style={styles.securityNote}>
        <Ionicons name="lock-closed" size={18} color={GovPalette.safe} />
        <Text style={styles.securityNoteText}>
          Your data is encrypted and protected. We use JWT authentication and AES-256 encryption.
        </Text>
      </View>

      <TouchableOpacity style={styles.goldButtonLight} onPress={submit}>
        <Text style={styles.goldButtonTextDark}>Create Account</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

function ParishPicker({ parish, setParish }) {
  const [open, setOpen] = useState(false);
  return (
    <View>
      <TouchableOpacity style={styles.parishSelect} onPress={() => setOpen((v) => !v)}>
        <Text style={{ color: '#1C1C1E' }}>{parish}</Text>
        <Ionicons name={open ? 'chevron-up' : 'chevron-down'} size={16} color="#6C6C70" />
      </TouchableOpacity>
      {open && (
        <View style={styles.parishList}>
          {AllParishes.map((p) => (
            <TouchableOpacity
              key={p}
              style={styles.parishItem}
              onPress={() => {
                setParish(p);
                setOpen(false);
              }}
            >
              <Text>{p}</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  topRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 24, paddingTop: 16 },
  dot: { height: 8, borderRadius: 4 },
  skipText: { color: 'rgba(255,255,255,0.7)', fontSize: FontSize.subheadline, fontWeight: '500' },
  bottomActions: { paddingHorizontal: 24, paddingBottom: 32, paddingTop: 8 },
  goldButton: {
    backgroundColor: GovPalette.gold,
    borderRadius: Radius.lg,
    paddingVertical: 16,
    alignItems: 'center',
  },
  goldButtonText: { color: GovPalette.jungle, fontSize: 17, fontWeight: '600' },
  ghostButton: {
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderRadius: Radius.lg,
    paddingVertical: 14,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  ghostButtonText: { color: '#fff', fontSize: 16, fontWeight: '500' },
  pageCenter: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 24 },
  emblem: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 2,
    borderColor: 'rgba(232,185,49,0.3)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  appName: { fontSize: FontSize.hero, fontWeight: '700', color: '#fff' },
  appSubtitle: { fontSize: FontSize.subheadline, fontWeight: '500', color: 'rgba(255,255,255,0.7)', textAlign: 'center', marginTop: 8 },
  tagline: { fontSize: FontSize.title1, fontWeight: '700', color: '#fff', textAlign: 'center', marginBottom: 12 },
  taglineDesc: { fontSize: FontSize.headline, color: 'rgba(255,255,255,0.75)', textAlign: 'center' },
  pageTitle: { fontSize: FontSize.title1, fontWeight: '700', color: '#fff', marginTop: 8, textAlign: 'center' },
  pageDesc: { fontSize: FontSize.subheadline, color: 'rgba(255,255,255,0.7)', textAlign: 'center', marginTop: 8 },
  langRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: Radius.lg,
    padding: 16,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  langRowSelected: { borderColor: GovPalette.gold },
  langFlag: {
    width: 40,
    height: 40,
    borderRadius: Radius.md,
    backgroundColor: 'rgba(232,185,49,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  langName: { color: '#fff', fontSize: 17, fontWeight: '500' },
  featureRow: { flexDirection: 'row', alignItems: 'center', gap: 16 },
  featureIconWrap: {
    width: 48,
    height: 48,
    borderRadius: Radius.md,
    backgroundColor: 'rgba(255,255,255,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  featureTitle: { color: '#fff', fontSize: FontSize.headline, fontWeight: '600' },
  featureDesc: { color: 'rgba(255,255,255,0.65)', fontSize: FontSize.body, marginTop: 4 },
  loginTitle: { fontSize: FontSize.title1, fontWeight: '700', color: '#1C1C1E' },
  loginDesc: { fontSize: FontSize.callout, color: '#6C6C70', textAlign: 'center', paddingHorizontal: 8 },
  securityNote: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: 'rgba(46,158,97,0.08)',
    padding: 14,
    borderRadius: Radius.md,
  },
  securityNoteText: { flex: 1, fontSize: FontSize.caption, color: '#6C6C70' },
  goldButtonLight: { backgroundColor: GovPalette.gold, borderRadius: Radius.lg, paddingVertical: 16, alignItems: 'center' },
  goldButtonTextDark: { color: GovPalette.jungle, fontSize: 17, fontWeight: '600' },
  parishSelect: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#E5E5EA',
    padding: 14,
    borderRadius: Radius.md,
  },
  parishList: { backgroundColor: '#fff', borderRadius: Radius.md, marginTop: 6, borderWidth: 1, borderColor: '#E5E5EA', maxHeight: 220 },
  parishItem: { padding: 12, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: '#E5E5EA' },
});
