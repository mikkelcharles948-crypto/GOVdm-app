import React, { useState, useMemo } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Linking, Alert, TextInput } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../state/AppContext';
import { GovPalette, FontSize, Radius } from '../theme/theme';
import {
  GovCard,
  GovPill,
  GovSearchBar,
  GovEmptyState,
  FilterChip,
  InfoRow,
  Divider,
  PrimaryButton,
  SoftButton,
} from '../components/GovComponents';
import { OfficeTypeList, OfficeTypeInfo, AllParishes } from '../data/enums';

export default function OfficeDirectoryScreen({ navigation }) {
  const { offices } = useApp();
  const [search, setSearch] = useState('');
  const [type, setType] = useState(null);
  const [parish, setParish] = useState(null);

  const filtered = useMemo(
    () =>
      offices.filter((o) => {
        const matchesSearch =
          !search ||
          o.name.toLowerCase().includes(search.toLowerCase()) ||
          o.address.toLowerCase().includes(search.toLowerCase());
        const matchesType = !type || o.type === type;
        const matchesParish = !parish || o.parish === parish;
        return matchesSearch && matchesType && matchesParish;
      }),
    [offices, search, type, parish]
  );

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={styles.content}>
      <GovSearchBar value={search} onChangeText={setSearch} placeholder="Search offices, departments..." />

      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginVertical: 10 }}>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <FilterChip title="All" isSelected={!type} onPress={() => setType(null)} />
          {OfficeTypeList.map((t) => (
            <FilterChip key={t} title={OfficeTypeInfo[t].displayName} isSelected={type === t} onPress={() => setType(t)} />
          ))}
        </View>
      </ScrollView>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 10 }}>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <FilterChip title="All Parishes" isSelected={!parish} onPress={() => setParish(null)} />
          {AllParishes.map((p) => (
            <FilterChip key={p} title={p} isSelected={parish === p} onPress={() => setParish(p)} />
          ))}
        </View>
      </ScrollView>

      <Text style={styles.countText}>{filtered.length} offices found</Text>

      {filtered.length === 0 ? (
        <GovEmptyState icon="business-outline" title="No Offices Found" message="Try adjusting your search or filters." />
      ) : (
        filtered.map((office) => (
          <TouchableOpacity key={office.id} onPress={() => navigation.navigate('OfficeDetail', { office })}>
            <OfficeCard office={office} />
          </TouchableOpacity>
        ))
      )}
    </ScrollView>
  );
}

export function OfficeCard({ office }) {
  const info = OfficeTypeInfo[office.type];
  return (
    <GovCard style={{ marginBottom: 12 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 10 }}>
        <View style={[styles.typeIconWrap, { backgroundColor: `${info.color}1A` }]}>
          <Ionicons name={info.icon} size={20} color={info.color} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.officeName} numberOfLines={2}>
            {office.name}
          </Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 2 }}>
            <GovPill text={info.displayName} color={info.color} />
            <Text style={styles.parishText}>{office.parish}</Text>
          </View>
        </View>
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        <Ionicons name="location" size={12} color="#6C6C70" />
        <Text style={styles.addressText} numberOfLines={1}>
          {office.address}
        </Text>
      </View>
    </GovCard>
  );
}

export function OfficeDetailScreen({ route, navigation }) {
  const { office } = route.params;
  const { favoriteOffices, toggleFavoriteOffice } = useApp();
  const info = OfficeTypeInfo[office.type];
  const isFav = favoriteOffices.includes(office.id);

  const call = (phone) => Linking.openURL(`tel:${phone.replace(/[+ ]/g, '')}`);
  const email = (addr) => Linking.openURL(`mailto:${addr}`);
  const openMaps = () => {
    const q = encodeURIComponent(office.name);
    Linking.openURL(`https://maps.google.com/?q=${q}&ll=${office.latitude},${office.longitude}`);
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={styles.content}>
      <LinearGradient colors={[info.color, `${info.color}B3`]} style={styles.hero}>
        <View style={styles.heroIconWrap}>
          <Ionicons name={info.icon} size={40} color="#fff" />
        </View>
        <Text style={styles.heroTitle}>{office.name}</Text>
        <GovPill text={info.displayName} color="#fff" />
      </LinearGradient>

      <GovCard style={{ marginTop: 16 }}>
        <Text style={styles.cardHeading}>Contact Information</Text>
        <View style={{ height: 12 }} />
        {office.phoneNumbers.map((phone) => (
          <TouchableOpacity key={phone} style={styles.contactRow} onPress={() => call(phone)}>
            <Ionicons name="call" size={16} color={GovPalette.safe} />
            <Text style={styles.contactText}>{phone}</Text>
            <View style={{ flex: 1 }} />
            <Ionicons name="chevron-forward" size={14} color="#8E8E93" />
          </TouchableOpacity>
        ))}
        {office.email && (
          <TouchableOpacity style={styles.contactRow} onPress={() => email(office.email)}>
            <Ionicons name="mail" size={16} color={GovPalette.info} />
            <Text style={styles.contactText}>{office.email}</Text>
            <View style={{ flex: 1 }} />
            <Ionicons name="chevron-forward" size={14} color="#8E8E93" />
          </TouchableOpacity>
        )}
        {office.website && (
          <View style={styles.contactRow}>
            <Ionicons name="globe" size={16} color={GovPalette.gold} />
            <Text style={styles.contactText}>{office.website}</Text>
          </View>
        )}
      </GovCard>

      <GovCard style={{ marginTop: 16 }}>
        <Text style={styles.cardHeading}>Office Details</Text>
        <View style={{ height: 12 }} />
        <InfoRow label="Address" value={office.address} />
        <Divider />
        <View style={{ height: 12 }} />
        <InfoRow label="Parish" value={office.parish} />
        <Divider />
        <View style={{ height: 12 }} />
        <InfoRow label="Office Hours" value={office.officeHours} />
        {office.departmentHead ? (
          <>
            <Divider />
            <View style={{ height: 12 }} />
            <InfoRow label="Department Head" value={office.departmentHead} />
          </>
        ) : null}
      </GovCard>

      {office.servicesOffered.length > 0 && (
        <GovCard style={{ marginTop: 16 }}>
          <Text style={styles.cardHeading}>Services Offered</Text>
          <View style={{ height: 10 }} />
          {office.servicesOffered.map((s) => (
            <View key={s} style={styles.serviceRow}>
              <Ionicons name="checkmark-circle" size={16} color={GovPalette.safe} />
              <Text style={styles.serviceText}>{s}</Text>
            </View>
          ))}
        </GovCard>
      )}

      {office.allowsAppointments && (
        <View style={{ marginTop: 16 }}>
          <PrimaryButton
            title="Book Appointment"
            icon="calendar"
            onPress={() => navigation.navigate('AppointmentBooking', { office })}
          />
        </View>
      )}

      <View style={{ marginTop: 12 }}>
        <SoftButton title="Get Directions" icon="navigate" onPress={openMaps} color={GovPalette.gold} textColor={GovPalette.jungle} />
      </View>

      <View style={{ marginTop: 12, marginBottom: 8 }}>
        <SoftButton
          title={isFav ? 'Saved to Favorites' : 'Add to Favorites'}
          icon={isFav ? 'star' : 'star-outline'}
          onPress={() => toggleFavoriteOffice(office.id)}
          color="#8E8E93"
          textColor={GovPalette.gold}
        />
      </View>
    </ScrollView>
  );
}

export function AppointmentBookingScreen({ route, navigation }) {
  const { office } = route.params;
  const [selectedService, setSelectedService] = useState('');
  const [notes, setNotes] = useState('');

  const submit = () => {
    Alert.alert(
      'Appointment Requested',
      `Your appointment request for ${selectedService} at ${office.name} has been submitted. You will receive a confirmation notification.`,
      [{ text: 'Done', onPress: () => navigation.goBack() }]
    );
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={styles.content}>
      <GovCard style={{ marginBottom: 16 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <Ionicons name={OfficeTypeInfo[office.type].icon} size={20} color={OfficeTypeInfo[office.type].color} />
          <View style={{ flex: 1 }}>
            <Text style={styles.officeName} numberOfLines={1}>
              {office.name}
            </Text>
            <Text style={styles.parishText}>{office.address}</Text>
          </View>
        </View>
      </GovCard>

      <GovCard style={{ marginBottom: 16 }}>
        <Text style={styles.cardHeading}>Select Service</Text>
        <View style={{ height: 10 }} />
        {office.servicesOffered.map((s) => (
          <TouchableOpacity
            key={s}
            style={[styles.serviceOption, selectedService === s && { backgroundColor: `${GovPalette.gold}1A` }]}
            onPress={() => setSelectedService(s)}
          >
            <Ionicons
              name={selectedService === s ? 'checkmark-circle' : 'ellipse-outline'}
              size={18}
              color={selectedService === s ? GovPalette.gold : '#8E8E93'}
            />
            <Text style={{ fontSize: FontSize.subheadline }}>{s}</Text>
          </TouchableOpacity>
        ))}
      </GovCard>

      <GovCard style={{ marginBottom: 16 }}>
        <Text style={styles.cardHeading}>Additional Notes</Text>
        <View style={{ height: 8 }} />
        <GovFormFieldNote notes={notes} setNotes={setNotes} />
      </GovCard>

      <PrimaryButton
        title="Request Appointment"
        onPress={submit}
        disabled={!selectedService}
      />
    </ScrollView>
  );
}

function GovFormFieldNote({ notes, setNotes }) {
  return (
    <TextInput
      value={notes}
      onChangeText={setNotes}
      placeholder="Any specific requests..."
      multiline
      style={{ minHeight: 80, backgroundColor: '#E5E5EA', borderRadius: Radius.md, padding: 12, fontSize: FontSize.subheadline, textAlignVertical: 'top' }}
    />
  );
}

const styles = StyleSheet.create({
  content: { padding: 16, paddingBottom: 32 },
  countText: { fontSize: FontSize.body, fontWeight: '500', color: '#6C6C70', marginBottom: 10 },
  typeIconWrap: { width: 44, height: 44, borderRadius: Radius.md, alignItems: 'center', justifyContent: 'center' },
  officeName: { fontSize: FontSize.subheadline, fontWeight: '700', color: '#1C1C1E' },
  parishText: { fontSize: FontSize.caption, color: '#6C6C70' },
  addressText: { fontSize: FontSize.body, color: '#6C6C70', flexShrink: 1 },
  hero: { alignItems: 'center', paddingVertical: 28, borderRadius: Radius.xxl, gap: 10 },
  heroIconWrap: { width: 90, height: 90, borderRadius: 45, backgroundColor: 'rgba(255,255,255,0.2)', alignItems: 'center', justifyContent: 'center' },
  heroTitle: { fontSize: FontSize.title2, fontWeight: '700', color: '#fff', textAlign: 'center', paddingHorizontal: 20 },
  cardHeading: { fontSize: FontSize.title3, fontWeight: '700', color: '#1C1C1E' },
  contactRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 8 },
  contactText: { fontSize: FontSize.subheadline, fontWeight: '500', color: '#1C1C1E' },
  serviceRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 4 },
  serviceText: { fontSize: FontSize.callout, color: '#1C1C1E' },
  serviceOption: { flexDirection: 'row', alignItems: 'center', gap: 10, padding: 10, borderRadius: Radius.sm },
});
