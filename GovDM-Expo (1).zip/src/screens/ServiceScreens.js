import React, { useState } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, TextInput, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../state/AppContext';
import { GovPalette, FontSize, Radius } from '../theme/theme';
import {
  GovCard,
  GovSectionHeader,
  GovStatusBadge,
  GovEmptyState,
  GovFormField,
  PrimaryButton,
  InfoRow,
  Divider,
  withAlpha,
} from '../components/GovComponents';
import { ServiceRequestTypeList, ServiceRequestTypeInfo, PublicWorksTypeList, PublicWorksTypeInfo } from '../data/enums';

export default function ServicesScreen({ navigation }) {
  const { isLoggedIn, serviceRequests } = useApp();

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={styles.content}>
      <TouchableOpacity onPress={() => navigation.navigate('PublicWorks')}>
        <View style={styles.publicWorksBanner}>
          <Ionicons name="construct" size={22} color="#fff" />
          <View style={{ flex: 1 }}>
            <Text style={styles.bannerTitle}>Report a Public Works Issue</Text>
            <Text style={styles.bannerSub}>Potholes, streetlights, drainage & more</Text>
          </View>
          <Ionicons name="chevron-forward" size={18} color="#fff" />
        </View>
      </TouchableOpacity>

      {isLoggedIn && (
        <View style={styles.section}>
          <GovSectionHeader
            title="My Requests"
            actionTitle={serviceRequests.length > 0 ? 'See all' : undefined}
            onAction={() => navigation.navigate('MyServiceRequests')}
          />
          {serviceRequests.length === 0 ? (
            <GovCard>
              <Text style={styles.emptyText}>You haven't submitted any service requests yet.</Text>
            </GovCard>
          ) : (
            serviceRequests.slice(0, 2).map((r) => (
              <TouchableOpacity key={r.id} onPress={() => navigation.navigate('ServiceRequestDetail', { request: r })}>
                <ServiceRequestCard request={r} />
              </TouchableOpacity>
            ))
          )}
        </View>
      )}

      <View style={styles.section}>
        <GovSectionHeader title="Apply for a Service" />
        {ServiceRequestTypeList.map((type) => (
          <TouchableOpacity key={type} onPress={() => navigation.navigate('NewServiceRequest', { type })}>
            <ServiceTypeRow type={type} />
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );
}

export function ServiceTypeRow({ type }) {
  const info = ServiceRequestTypeInfo[type];
  return (
    <GovCard style={{ marginBottom: 10 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <View style={[styles.iconWrap, { backgroundColor: withAlpha(GovPalette.jungle, 0.1) }]}>
          <Ionicons name={info.icon} size={20} color={GovPalette.jungle} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.serviceTitle}>{info.displayName}</Text>
          <Text style={styles.serviceDept} numberOfLines={1}>
            {info.department}
          </Text>
          <Text style={styles.serviceTime}>{info.processingTime}</Text>
        </View>
        <Ionicons name="chevron-forward" size={16} color="#8E8E93" />
      </View>
    </GovCard>
  );
}

export function ServiceRequestCard({ request }) {
  const info = ServiceRequestTypeInfo[request.type];
  return (
    <GovCard style={{ marginBottom: 12 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 10 }}>
        <Ionicons name={info.icon} size={20} color={GovPalette.jungle} />
        <View style={{ flex: 1 }}>
          <Text style={styles.serviceTitle}>{info.displayName}</Text>
          <Text style={styles.serviceTime}>{request.trackingCode}</Text>
        </View>
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <GovStatusBadge status={request.status} />
        <View style={{ flex: 1 }} />
        <Text style={styles.serviceTime}>{new Date(request.createdAt).toLocaleDateString()}</Text>
      </View>
    </GovCard>
  );
}

export function NewServiceRequestScreen({ route, navigation }) {
  const type = route.params?.type ?? ServiceRequestTypeList[0];
  const info = ServiceRequestTypeInfo[type];
  const { submitServiceRequest, currentUser, isLoggedIn } = useApp();

  const [applicantName, setApplicantName] = useState(isLoggedIn ? currentUser.name : '');
  const [applicantContact, setApplicantContact] = useState(isLoggedIn ? currentUser.phone : '');
  const [details, setDetails] = useState('');

  const submit = () => {
    if (!applicantName || !applicantContact) {
      Alert.alert('Missing information', 'Please fill in your name and contact information.');
      return;
    }
    submitServiceRequest({ type, applicantName, applicantContact, details });
    Alert.alert('Request Submitted', `Your ${info.displayName} request has been submitted.`, [
      { text: 'Done', onPress: () => navigation.popToTop() },
    ]);
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={styles.content}>
      <GovCard style={{ marginBottom: 16 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <Ionicons name={info.icon} size={24} color={GovPalette.jungle} />
          <View style={{ flex: 1 }}>
            <Text style={styles.reqHeading}>{info.displayName}</Text>
            <Text style={styles.serviceDept}>{info.department}</Text>
          </View>
        </View>
        <Divider />
        <View style={{ height: 10 }} />
        <InfoRow label="Estimated Processing" value={info.processingTime} />
      </GovCard>

      <View style={{ gap: 16 }}>
        <GovFormField label="Full Name" value={applicantName} onChangeText={setApplicantName} placeholder="Your full name" />
        <GovFormField
          label="Contact (Phone or Email)"
          value={applicantContact}
          onChangeText={setApplicantContact}
          placeholder="+1 767-XXX-XXXX"
        />
        <View style={{ gap: 8 }}>
          <Text style={styles.formLabel}>Additional Details</Text>
          <TextInput
            value={details}
            onChangeText={setDetails}
            placeholder="Any additional information for this application..."
            multiline
            style={styles.textArea}
          />
        </View>
      </View>

      <View style={{ height: 24 }} />
      <PrimaryButton title="Submit Application" onPress={submit} />
    </ScrollView>
  );
}

export function MyServiceRequestsScreen({ navigation }) {
  const { serviceRequests } = useApp();
  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={styles.content}>
      {serviceRequests.length === 0 ? (
        <GovEmptyState icon="laptop-outline" title="No Requests" message="You haven't submitted any service requests yet." />
      ) : (
        serviceRequests.map((r) => (
          <TouchableOpacity key={r.id} onPress={() => navigation.navigate('ServiceRequestDetail', { request: r })}>
            <ServiceRequestCard request={r} />
          </TouchableOpacity>
        ))
      )}
    </ScrollView>
  );
}

export function ServiceRequestDetailScreen({ route }) {
  const { request } = route.params;
  const info = ServiceRequestTypeInfo[request.type];
  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={styles.content}>
      <GovCard style={{ marginBottom: 16, alignItems: 'center', paddingVertical: 24 }}>
        <Ionicons name={info.icon} size={40} color={GovPalette.jungle} />
        <Text style={[styles.reqHeading, { marginTop: 10 }]}>{info.displayName}</Text>
        <Text style={styles.serviceTime}>{request.trackingCode}</Text>
        <View style={{ height: 10 }} />
        <GovStatusBadge status={request.status} />
      </GovCard>

      <GovCard style={{ marginBottom: 16 }}>
        <Text style={styles.reqHeading}>Application Details</Text>
        <View style={{ height: 12 }} />
        <InfoRow label="Department" value={info.department} />
        <Divider />
        <View style={{ height: 12 }} />
        <InfoRow label="Applicant" value={request.applicantName} />
        <Divider />
        <View style={{ height: 12 }} />
        <InfoRow label="Contact" value={request.applicantContact} />
        <Divider />
        <View style={{ height: 12 }} />
        <InfoRow label="Submitted" value={new Date(request.createdAt).toLocaleDateString()} />
        {request.details ? (
          <>
            <Divider />
            <View style={{ height: 12 }} />
            <InfoRow label="Notes" value={request.details} />
          </>
        ) : null}
      </GovCard>
    </ScrollView>
  );
}

export function PublicWorksScreen({ navigation }) {
  const { submitReport, isGuest } = useApp();
  const [selectedType, setSelectedType] = useState(null);
  const [description, setDescription] = useState('');
  const [address, setAddress] = useState('');
  const [anonymous, setAnonymous] = useState(isGuest);

  const submit = () => {
    if (!selectedType || !description) {
      Alert.alert('Missing information', 'Please select an issue type and add a description.');
      return;
    }
    submitReport({
      category: 'roadDamage',
      title: PublicWorksTypeInfo[selectedType].displayName,
      description,
      address,
      isAnonymous: anonymous,
      department: 'Ministry of Public Works',
    });
    Alert.alert('Reported', 'Thank you — the Ministry of Public Works has been notified.', [
      { text: 'Done', onPress: () => navigation.goBack() },
    ]);
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={styles.content}>
      <Text style={styles.reqHeading}>What's the issue?</Text>
      <View style={{ height: 12 }} />
      <View style={styles.typeGrid}>
        {PublicWorksTypeList.map((t) => {
          const info = PublicWorksTypeInfo[t];
          const selected = selectedType === t;
          return (
            <TouchableOpacity
              key={t}
              style={[styles.typeTile, selected && { backgroundColor: withAlpha(GovPalette.jungle, 0.12), borderColor: GovPalette.jungle }]}
              onPress={() => setSelectedType(t)}
            >
              <Ionicons name={info.icon} size={22} color={selected ? GovPalette.jungle : '#6C6C70'} />
              <Text style={[styles.typeTileText, selected && { color: GovPalette.jungle, fontWeight: '700' }]}>
                {info.displayName}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>

      <View style={{ height: 20 }} />
      <GovFormField label="Location / Address" value={address} onChangeText={setAddress} placeholder="e.g. Near Roseau Market" />
      <View style={{ height: 16 }} />
      <Text style={styles.formLabel}>Description</Text>
      <View style={{ height: 8 }} />
      <TextInput
        value={description}
        onChangeText={setDescription}
        placeholder="Describe the issue..."
        multiline
        style={styles.textArea}
      />

      <TouchableOpacity style={styles.anonRow} onPress={() => setAnonymous((v) => !v)}>
        <Ionicons name={anonymous ? 'checkbox' : 'square-outline'} size={20} color={anonymous ? GovPalette.jungle : '#8E8E93'} />
        <Text style={styles.anonText}>Report anonymously</Text>
      </TouchableOpacity>

      <View style={{ height: 12 }} />
      <PrimaryButton title="Submit Report" icon="paper-plane" onPress={submit} color={GovPalette.warning} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  content: { padding: 16, paddingBottom: 32 },
  publicWorksBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: GovPalette.warning,
    padding: 16,
    borderRadius: Radius.lg,
    marginBottom: 8,
  },
  bannerTitle: { color: '#fff', fontSize: FontSize.headline, fontWeight: '700' },
  bannerSub: { color: 'rgba(255,255,255,0.85)', fontSize: FontSize.caption, marginTop: 2 },
  section: { marginTop: 20, gap: 10 },
  emptyText: { fontSize: FontSize.body, color: '#6C6C70', textAlign: 'center', paddingVertical: 8 },
  iconWrap: { width: 44, height: 44, borderRadius: Radius.md, alignItems: 'center', justifyContent: 'center' },
  serviceTitle: { fontSize: FontSize.subheadline, fontWeight: '700', color: '#1C1C1E' },
  serviceDept: { fontSize: FontSize.caption, color: '#6C6C70', marginTop: 2 },
  serviceTime: { fontSize: FontSize.sm, color: '#8E8E93', marginTop: 2 },
  reqHeading: { fontSize: FontSize.title3, fontWeight: '700', color: '#1C1C1E' },
  formLabel: { fontSize: FontSize.callout, fontWeight: '500', color: '#6C6C70' },
  textArea: { minHeight: 100, backgroundColor: '#E5E5EA', borderRadius: Radius.md, padding: 14, fontSize: FontSize.subheadline, textAlignVertical: 'top' },
  typeGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  typeTile: {
    width: '31%',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 14,
    borderRadius: Radius.md,
    borderWidth: 1.5,
    borderColor: '#E5E5EA',
    backgroundColor: '#F9F9F9',
  },
  typeTileText: { fontSize: FontSize.xs, color: '#1C1C1E', textAlign: 'center' },
  anonRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 16, marginBottom: 8 },
  anonText: { fontSize: FontSize.subheadline, color: '#1C1C1E' },
});
