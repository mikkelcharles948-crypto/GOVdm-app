import React, { useState, useMemo } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../state/AppContext';
import { GovPalette, FontSize, Radius } from '../theme/theme';
import { GovSearchBar, GovEmptyState, FlowLayout } from '../components/GovComponents';
import { OfficeCard } from './OfficeDirectoryScreen';
import { AnnouncementCard } from './HomeScreen';
import { TourismSiteCard } from './TourismScreen';
import { ClinicCard } from './HealthScreen';
import { ShelterCard } from './DisasterScreens';
import { ServiceTypeRow } from './ServiceScreens';
import { ServiceRequestTypeList, ServiceRequestTypeInfo } from '../data/enums';

const popularSearches = [
  'Birth Certificate', 'Police', 'Hospital', 'Hurricane',
  'Building Permit', 'Shelter', 'Tax', 'Vaccination',
  'Roseau', 'Boiling Lake', 'Road Closure',
];

export default function SearchScreen({ navigation }) {
  const { offices, announcements, tourismSites, clinics, shelters, emergencyAlerts } = useApp();
  const [query, setQuery] = useState('');

  const results = useMemo(() => {
    const q = query.toLowerCase();
    if (!q) return null;
    return {
      offices: offices.filter((o) => o.name.toLowerCase().includes(q) || o.address.toLowerCase().includes(q)),
      announcements: announcements.filter(
        (a) => a.title.toLowerCase().includes(q) || a.summary.toLowerCase().includes(q) || a.tags.join(' ').toLowerCase().includes(q)
      ),
      services: ServiceRequestTypeList.filter(
        (t) =>
          ServiceRequestTypeInfo[t].displayName.toLowerCase().includes(q) ||
          ServiceRequestTypeInfo[t].department.toLowerCase().includes(q)
      ),
      tourism: tourismSites.filter((t) => t.name.toLowerCase().includes(q) || t.description.toLowerCase().includes(q)),
      clinics: clinics.filter((c) => c.name.toLowerCase().includes(q) || c.address.toLowerCase().includes(q)),
      shelters: shelters.filter((s) => s.name.toLowerCase().includes(q)),
      alerts: emergencyAlerts.filter((a) => a.title.toLowerCase().includes(q) || a.message.toLowerCase().includes(q)),
    };
  }, [query, offices, announcements, tourismSites, clinics, shelters, emergencyAlerts]);

  const isEmpty =
    results &&
    Object.values(results).every((arr) => arr.length === 0);

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={styles.content}>
      <GovSearchBar value={query} onChangeText={setQuery} placeholder="Search everything..." />

      {!query ? (
        <View style={{ gap: 16, marginTop: 16 }}>
          <View>
            <Text style={styles.sectionTitle}>Popular Searches</Text>
            <View style={{ height: 10 }} />
            <FlowLayout>
              {popularSearches.map((s) => (
                <TouchableOpacity key={s} style={styles.suggestionChip} onPress={() => setQuery(s)}>
                  <Ionicons name="search" size={11} color="#1C1C1E" />
                  <Text style={styles.suggestionText}>{s}</Text>
                </TouchableOpacity>
              ))}
            </FlowLayout>
          </View>

          <View>
            <Text style={styles.sectionTitle}>Browse by Category</Text>
            <View style={{ height: 10 }} />
            <View style={styles.categoryGrid}>
              {[
                { icon: 'business', title: 'Offices', color: GovPalette.jungle },
                { icon: 'laptop-outline', title: 'Services', color: GovPalette.info },
                { icon: 'chatbubble-ellipses', title: 'Reports', color: GovPalette.emergency },
                { icon: 'leaf', title: 'Tourism', color: GovPalette.safe },
                { icon: 'medkit', title: 'Health', color: GovPalette.emergency },
                { icon: 'thunderstorm', title: 'Disaster', color: GovPalette.warning },
              ].map((c) => (
                <View key={c.title} style={styles.categoryTile}>
                  <Ionicons name={c.icon} size={22} color={c.color} />
                  <Text style={styles.categoryTitle}>{c.title}</Text>
                </View>
              ))}
            </View>
          </View>
        </View>
      ) : isEmpty ? (
        <GovEmptyState icon="search" title="No Results Found" message={`No results for "${query}". Try different keywords.`} />
      ) : (
        <View style={{ marginTop: 16, gap: 16 }}>
          <ResultSection title="Emergency Alerts" items={results.alerts}>
            {results.alerts.map((a) => (
              <Text key={a.id} style={styles.alertLine}>
                ⚠ {a.title}
              </Text>
            ))}
          </ResultSection>

          <ResultSection title="Government Offices" items={results.offices}>
            {results.offices.map((o) => (
              <TouchableOpacity key={o.id} onPress={() => navigation.navigate('OfficeDetail', { office: o })}>
                <OfficeCard office={o} />
              </TouchableOpacity>
            ))}
          </ResultSection>

          <ResultSection title="Services" items={results.services}>
            {results.services.map((s) => (
              <ServiceTypeRow key={s} type={s} />
            ))}
          </ResultSection>

          <ResultSection title="Announcements" items={results.announcements}>
            {results.announcements.map((a) => (
              <TouchableOpacity key={a.id} onPress={() => navigation.navigate('AnnouncementDetail', { announcement: a })}>
                <AnnouncementCard announcement={a} />
              </TouchableOpacity>
            ))}
          </ResultSection>

          <ResultSection title="Tourism" items={results.tourism}>
            {results.tourism.map((t) => (
              <TouchableOpacity key={t.id} onPress={() => navigation.navigate('TourismSiteDetail', { site: t })}>
                <TourismSiteCard site={t} />
              </TouchableOpacity>
            ))}
          </ResultSection>

          <ResultSection title="Health Facilities" items={results.clinics}>
            {results.clinics.map((c) => (
              <ClinicCard key={c.id} clinic={c} />
            ))}
          </ResultSection>

          <ResultSection title="Shelters" items={results.shelters}>
            {results.shelters.map((s) => (
              <ShelterCard key={s.id} shelter={s} />
            ))}
          </ResultSection>
        </View>
      )}
    </ScrollView>
  );
}

function ResultSection({ title, items, children }) {
  if (!items || items.length === 0) return null;
  return (
    <View>
      <View style={{ flexDirection: 'row', alignItems: 'baseline', gap: 6, marginBottom: 10 }}>
        <Text style={styles.resultTitle}>{title}</Text>
        <Text style={styles.resultCount}>({items.length})</Text>
      </View>
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  content: { padding: 16, paddingBottom: 32 },
  sectionTitle: { fontSize: FontSize.headline, fontWeight: '700', color: '#1C1C1E' },
  suggestionChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#E5E5EA',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: Radius.pill,
  },
  suggestionText: { fontSize: FontSize.body, fontWeight: '500', color: '#1C1C1E' },
  categoryGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  categoryTile: {
    width: '47%',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 14,
    backgroundColor: '#F2F2F7',
    borderRadius: Radius.lg,
  },
  categoryTitle: { fontSize: FontSize.body, fontWeight: '500', color: '#1C1C1E' },
  resultTitle: { fontSize: FontSize.title3, fontWeight: '700', color: '#1C1C1E' },
  resultCount: { fontSize: FontSize.callout, fontWeight: '500', color: '#6C6C70' },
  alertLine: { fontSize: FontSize.subheadline, color: GovPalette.emergency, marginBottom: 8, fontWeight: '600' },
});
