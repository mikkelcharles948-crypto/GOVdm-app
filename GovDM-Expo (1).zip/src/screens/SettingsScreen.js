import React from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Switch, Linking, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../state/AppContext';
import { GovPalette, FontSize, Radius } from '../theme/theme';
import { GovCard, withAlpha } from '../components/GovComponents';
import { AppLanguageList, AppLanguageInfo } from '../data/enums';

export default function SettingsScreen({ navigation }) {
  const {
    currentUser,
    isLoggedIn,
    isGuest,
    logout,
    language,
    updateLanguage,
    largeText,
    toggleLargeText,
    highContrast,
    toggleHighContrast,
    reduceMotion,
    toggleReduceMotion,
  } = useApp();

  const confirmLogout = () => {
    Alert.alert('Log Out', 'Are you sure you want to log out?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Log Out', style: 'destructive', onPress: logout },
    ]);
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={styles.content}>
      {/* Profile */}
      <View style={styles.profileRow}>
        <View style={styles.avatar}>
          <Ionicons name="person" size={28} color="#fff" />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.profileName}>{isLoggedIn ? currentUser.name : 'Guest User'}</Text>
          <Text style={styles.profileSub}>{isLoggedIn ? currentUser.email : 'Not signed in'}</Text>
        </View>
      </View>

      {isGuest && (
        <TouchableOpacity style={styles.upgradeBanner} onPress={() => navigation.navigate('Login')}>
          <Ionicons name="person-add" size={18} color="#fff" />
          <Text style={styles.upgradeText}>Create a Citizen Account for full access</Text>
          <View style={{ flex: 1 }} />
          <Ionicons name="chevron-forward" size={16} color="#fff" />
        </TouchableOpacity>
      )}

      {/* Language */}
      <SectionCard title="Language">
        {AppLanguageList.map((lang) => {
          const info = AppLanguageInfo[lang];
          const selected = language === lang;
          return (
            <TouchableOpacity key={lang} style={styles.row} onPress={() => updateLanguage(lang)}>
              <View style={styles.flagChip}>
                <Text style={{ fontSize: 10, fontWeight: '700', color: GovPalette.jungle }}>{info.flag}</Text>
              </View>
              <Text style={styles.rowText}>{info.displayName}</Text>
              <View style={{ flex: 1 }} />
              {selected && <Ionicons name="checkmark" size={18} color={GovPalette.jungle} />}
            </TouchableOpacity>
          );
        })}
      </SectionCard>

      {/* Accessibility */}
      <SectionCard title="Accessibility">
        <ToggleRow icon="text" label="Large Text" value={largeText} onToggle={toggleLargeText} />
        <ToggleRow icon="contrast" label="High Contrast" value={highContrast} onToggle={toggleHighContrast} />
        <ToggleRow icon="pulse" label="Reduce Motion" value={reduceMotion} onToggle={toggleReduceMotion} />
      </SectionCard>

      {/* Support */}
      <SectionCard title="Support">
        <Row icon="help-circle" label="Help & FAQ" onPress={() => {}} />
        <Row icon="mail" label="Contact Support" onPress={() => Linking.openURL('mailto:support@gov.dm')} />
        <Row icon="document-text" label="Terms of Service" onPress={() => {}} />
        <Row icon="shield-checkmark" label="Privacy Policy" onPress={() => {}} />
      </SectionCard>

      {/* About */}
      <SectionCard title="About">
        <Row icon="information-circle" label="App Version" value="1.0.0" />
        <Row icon="business" label="Government of Dominica" value="gov.dm" />
      </SectionCard>

      {isLoggedIn && (
        <TouchableOpacity style={styles.logoutButton} onPress={confirmLogout}>
          <Ionicons name="log-out" size={18} color={GovPalette.emergency} />
          <Text style={styles.logoutText}>Log Out</Text>
        </TouchableOpacity>
      )}
    </ScrollView>
  );
}

function SectionCard({ title, children }) {
  return (
    <View style={{ marginTop: 20 }}>
      <Text style={styles.sectionTitle}>{title}</Text>
      <GovCard style={{ marginTop: 10 }} padding={4}>
        {children}
      </GovCard>
    </View>
  );
}

function ToggleRow({ icon, label, value, onToggle }) {
  return (
    <View style={styles.row}>
      <Ionicons name={icon} size={18} color={GovPalette.jungle} style={styles.rowIcon} />
      <Text style={styles.rowText}>{label}</Text>
      <View style={{ flex: 1 }} />
      <Switch value={value} onValueChange={onToggle} trackColor={{ true: GovPalette.jungle }} />
    </View>
  );
}

function Row({ icon, label, value, onPress }) {
  return (
    <TouchableOpacity style={styles.row} onPress={onPress} disabled={!onPress}>
      <Ionicons name={icon} size={18} color={GovPalette.jungle} style={styles.rowIcon} />
      <Text style={styles.rowText}>{label}</Text>
      <View style={{ flex: 1 }} />
      {value ? <Text style={styles.rowValue}>{value}</Text> : null}
      {onPress ? <Ionicons name="chevron-forward" size={14} color="#8E8E93" /> : null}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  content: { padding: 16, paddingBottom: 40 },
  profileRow: { flexDirection: 'row', alignItems: 'center', gap: 14, marginBottom: 12 },
  avatar: { width: 56, height: 56, borderRadius: 28, backgroundColor: GovPalette.jungle, alignItems: 'center', justifyContent: 'center' },
  profileName: { fontSize: FontSize.title3, fontWeight: '700', color: '#1C1C1E' },
  profileSub: { fontSize: FontSize.body, color: '#6C6C70', marginTop: 2 },
  upgradeBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: GovPalette.gold,
    padding: 14,
    borderRadius: Radius.lg,
    marginTop: 8,
  },
  upgradeText: { color: GovPalette.jungle, fontWeight: '700', fontSize: FontSize.body, flexShrink: 1 },
  sectionTitle: { fontSize: FontSize.caption, fontWeight: '700', color: '#8E8E93', textTransform: 'uppercase', letterSpacing: 0.5 },
  row: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, paddingVertical: 13, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: '#E5E5EA' },
  rowIcon: { width: 26 },
  rowText: { fontSize: FontSize.subheadline, color: '#1C1C1E' },
  rowValue: { fontSize: FontSize.body, color: '#6C6C70', marginRight: 6 },
  flagChip: { width: 26, height: 26, borderRadius: 13, backgroundColor: withAlpha(GovPalette.jungle, 0.1), alignItems: 'center', justifyContent: 'center', marginRight: 4 },
  logoutButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 28, paddingVertical: 14 },
  logoutText: { color: GovPalette.emergency, fontWeight: '600', fontSize: FontSize.subheadline },
});
