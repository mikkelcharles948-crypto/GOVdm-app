import React from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Linking } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../state/AppContext';
import { GovPalette, FontSize, Radius } from '../theme/theme';
import { GovCard, GovSectionHeader, GovPill, withAlpha } from '../components/GovComponents';

export default function HealthScreen() {
  const { healthCampaigns, clinics } = useApp();

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={styles.content}>
      {/* Emergency banner */}
      <View style={styles.emergencyBanner}>
        <View style={styles.emergencyIconWrap}>
          <Ionicons name="medkit" size={22} color="#fff" />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.emergencyLabel}>Medical Emergency</Text>
          <Text style={styles.emergencyValue}>Call 999 for Ambulance</Text>
        </View>
        <TouchableOpacity style={styles.callButton} onPress={() => Linking.openURL('tel:999')}>
          <Text style={styles.callButtonText}>Call</Text>
        </TouchableOpacity>
      </View>

      {/* Quick actions */}
      <View style={styles.grid2}>
        <QuickTile icon="medical" title="Vaccinations" color={GovPalette.safe} />
        <QuickTile icon="calendar" title="Book Appointment" color={GovPalette.info} />
      </View>
      <View style={styles.grid2}>
        <QuickTile icon="heart" title="Health Records" color={GovPalette.emergency} />
        <QuickTile icon="medkit-outline" title="Pharmacy" color={GovPalette.gold} />
      </View>

      {/* Active campaigns */}
      <View style={styles.section}>
        <GovSectionHeader title="Active Campaigns" />
        {healthCampaigns.filter((c) => c.isActive).map((c) => (
          <HealthCampaignCard key={c.id} campaign={c} />
        ))}
      </View>

      {/* Clinics */}
      <View style={styles.section}>
        <GovSectionHeader title="Health Facilities" />
        {clinics.map((c) => (
          <ClinicCard key={c.id} clinic={c} />
        ))}
      </View>

      {/* Notices */}
      <View style={styles.section}>
        <GovSectionHeader title="Health Notices" />
        <GovCard style={{ marginBottom: 12 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 }}>
            <Ionicons name="water" size={16} color={GovPalette.info} />
            <Text style={styles.noticeTitle}>Water Safety Advisory</Text>
          </View>
          <Text style={styles.noticeBody}>
            Residents are advised to boil tap water before consumption in areas affected by recent heavy rainfall.
          </Text>
        </GovCard>
        <GovCard>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 }}>
            <Ionicons name="bug" size={16} color={GovPalette.warning} />
            <Text style={styles.noticeTitle}>Dengue Prevention</Text>
          </View>
          <Text style={styles.noticeBody}>
            Eliminate standing water around your home. Use insect repellent and wear long sleeves during peak
            mosquito hours (dawn and dusk).
          </Text>
        </GovCard>
      </View>
    </ScrollView>
  );
}

function QuickTile({ icon, title, color }) {
  return (
    <View style={styles.quickTile}>
      <View style={[styles.quickIconWrap, { backgroundColor: withAlpha(color, 0.12) }]}>
        <Ionicons name={icon} size={24} color={color} />
      </View>
      <Text style={styles.quickTitle}>{title}</Text>
    </View>
  );
}

export function HealthCampaignCard({ campaign }) {
  return (
    <GovCard style={{ marginBottom: 12 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 }}>
        <Ionicons name="megaphone" size={16} color={GovPalette.safe} />
        <Text style={styles.campaignTitle} numberOfLines={2}>
          {campaign.title}
        </Text>
        <View style={{ flex: 1 }} />
        <GovPill text="Active" color={GovPalette.safe} />
      </View>
      <Text style={styles.campaignDesc} numberOfLines={3}>
        {campaign.description}
      </Text>
      <View style={{ flexDirection: 'row', gap: 12, marginTop: 8 }}>
        <View style={styles.metaRow}>
          <Ionicons name="people" size={12} color="#6C6C70" />
          <Text style={styles.metaText}>{campaign.targetGroup}</Text>
        </View>
        <View style={styles.metaRow}>
          <Ionicons name="location" size={12} color="#6C6C70" />
          <Text style={styles.metaText}>{campaign.location}</Text>
        </View>
      </View>
    </GovCard>
  );
}

export function ClinicCard({ clinic }) {
  const color = clinic.isHospital ? GovPalette.emergency : GovPalette.safe;
  return (
    <GovCard style={{ marginBottom: 12 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 10 }}>
        <View style={[styles.clinicIconWrap, { backgroundColor: withAlpha(color, 0.1) }]}>
          <Ionicons name={clinic.isHospital ? 'medkit' : 'heart-half'} size={18} color={color} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.clinicName} numberOfLines={1}>
            {clinic.name}
          </Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 2 }}>
            <GovPill text={clinic.isHospital ? 'Hospital' : 'Health Centre'} color={color} />
            <Text style={styles.metaText}>{clinic.parish}</Text>
          </View>
        </View>
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 4 }}>
        <Ionicons name="location" size={12} color="#6C6C70" />
        <Text style={styles.clinicMeta} numberOfLines={1}>
          {clinic.address}
        </Text>
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 10 }}>
        <Ionicons name="time" size={12} color="#6C6C70" />
        <Text style={styles.clinicMeta}>{clinic.hours}</Text>
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 6 }}>
        {clinic.services.slice(0, 3).map((s) => (
          <GovPill key={s} text={s} color={GovPalette.info} />
        ))}
        {clinic.services.length > 3 && (
          <Text style={styles.moreText}>+{clinic.services.length - 3}</Text>
        )}
        <View style={{ flex: 1 }} />
        <TouchableOpacity style={styles.phoneButton} onPress={() => Linking.openURL(`tel:${clinic.phone.replace(/[+ ]/g, '')}`)}>
          <Ionicons name="call" size={14} color="#fff" />
        </TouchableOpacity>
      </View>
    </GovCard>
  );
}

const styles = StyleSheet.create({
  content: { padding: 16, paddingBottom: 32, gap: 0 },
  emergencyBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    padding: 16,
    backgroundColor: withAlpha(GovPalette.emergency, 0.08),
    borderRadius: Radius.xl,
    marginBottom: 20,
  },
  emergencyIconWrap: { width: 52, height: 52, borderRadius: 26, backgroundColor: GovPalette.emergency, alignItems: 'center', justifyContent: 'center' },
  emergencyLabel: { fontSize: FontSize.caption, color: '#6C6C70' },
  emergencyValue: { fontSize: FontSize.subheadline, fontWeight: '700', color: '#1C1C1E' },
  callButton: { backgroundColor: GovPalette.emergency, paddingHorizontal: 20, paddingVertical: 10, borderRadius: Radius.pill },
  callButtonText: { color: '#fff', fontWeight: '700', fontSize: FontSize.subheadline },
  grid2: { flexDirection: 'row', gap: 12, marginBottom: 12 },
  quickTile: { flex: 1, alignItems: 'center', paddingVertical: 14, backgroundColor: '#F2F2F7', borderRadius: Radius.lg },
  quickIconWrap: { width: 48, height: 48, borderRadius: Radius.md, alignItems: 'center', justifyContent: 'center', marginBottom: 8 },
  quickTitle: { fontSize: FontSize.body, fontWeight: '500', color: '#1C1C1E' },
  section: { marginTop: 20, gap: 12 },
  noticeTitle: { fontSize: FontSize.subheadline, fontWeight: '700', color: '#1C1C1E' },
  noticeBody: { fontSize: FontSize.body, color: '#6C6C70' },
  campaignTitle: { fontSize: FontSize.subheadline, fontWeight: '700', color: '#1C1C1E', flexShrink: 1 },
  campaignDesc: { fontSize: FontSize.body, color: '#6C6C70' },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  metaText: { fontSize: FontSize.caption, color: '#6C6C70' },
  clinicIconWrap: { width: 44, height: 44, borderRadius: Radius.md, alignItems: 'center', justifyContent: 'center' },
  clinicName: { fontSize: FontSize.subheadline, fontWeight: '700', color: '#1C1C1E' },
  clinicMeta: { fontSize: FontSize.body, color: '#6C6C70', flexShrink: 1 },
  moreText: { fontSize: FontSize.sm, fontWeight: '500', color: '#6C6C70' },
  phoneButton: { width: 40, height: 40, borderRadius: 20, backgroundColor: GovPalette.safe, alignItems: 'center', justifyContent: 'center' },
});
