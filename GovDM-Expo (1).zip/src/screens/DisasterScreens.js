import React, { useState } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Linking } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../state/AppContext';
import { GovPalette, FontSize, Radius } from '../theme/theme';
import { GovCard, GovSectionHeader, GovPill, GovEmptyState, withAlpha } from '../components/GovComponents';
import { EmergencyAlertCard } from './HomeScreen';
import { AlertSeverityInfo, ShelterStatusInfo } from '../data/enums';
import { EmergencyChecklist, OfflineGuideSections } from '../data/mockData';

export default function DisasterScreen({ navigation }) {
  const { emergencyAlerts, shelters } = useApp();
  const activeAlerts = emergencyAlerts.filter((a) => a.isActive);
  const openShelters = shelters.filter((s) => s.status === 'open').length;

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={styles.content}>
      <LinearGradient colors={[GovPalette.emergency, '#8F1218']} style={styles.hero}>
        <Ionicons name="thunderstorm" size={36} color="#fff" />
        <Text style={styles.heroTitle}>Disaster Preparedness</Text>
        <Text style={styles.heroDesc}>
          Stay informed, stay safe. {openShelters} shelter{openShelters === 1 ? '' : 's'} currently open.
        </Text>
      </LinearGradient>

      <TouchableOpacity onPress={() => navigation.navigate('Emergency')}>
        <View style={styles.emergencyCallout}>
          <Ionicons name="call" size={22} color="#fff" />
          <Text style={styles.emergencyCalloutText}>Emergency Hotlines</Text>
          <View style={{ flex: 1 }} />
          <Ionicons name="chevron-forward" size={16} color="#fff" />
        </View>
      </TouchableOpacity>

      {activeAlerts.length > 0 && (
        <View style={styles.section}>
          <GovSectionHeader title="Active Alerts" />
          {activeAlerts.map((a) => (
            <EmergencyAlertCard key={a.id} alert={a} />
          ))}
        </View>
      )}

      <View style={styles.section}>
        <GovSectionHeader title="Quick Access" />
        <View style={styles.grid2}>
          <QuickTile icon="home" title="Shelters" color={GovPalette.safe} onPress={() => navigation.navigate('ShelterList')} />
          <QuickTile icon="checkbox" title="Emergency Kit" color={GovPalette.warning} onPress={() => navigation.navigate('Checklist')} />
        </View>
        <View style={styles.grid2}>
          <QuickTile icon="book" title="Offline Guide" color={GovPalette.info} onPress={() => navigation.navigate('OfflineGuide')} />
          <QuickTile icon="call" title="Contacts" color={GovPalette.emergency} onPress={() => navigation.navigate('EmergencyContacts')} />
        </View>
      </View>

      <View style={styles.section}>
        <GovSectionHeader title="Nearby Shelters" actionTitle="See all" onAction={() => navigation.navigate('ShelterList')} />
        {shelters.slice(0, 2).map((s) => (
          <ShelterCard key={s.id} shelter={s} />
        ))}
      </View>
    </ScrollView>
  );
}

function QuickTile({ icon, title, color, onPress }) {
  return (
    <TouchableOpacity style={styles.quickTile} onPress={onPress} activeOpacity={0.7}>
      <View style={[styles.quickIconWrap, { backgroundColor: withAlpha(color, 0.12) }]}>
        <Ionicons name={icon} size={24} color={color} />
      </View>
      <Text style={styles.quickTitle}>{title}</Text>
    </TouchableOpacity>
  );
}

export function ShelterCard({ shelter }) {
  const info = ShelterStatusInfo[shelter.status];
  const occupancyPct = shelter.capacity > 0 ? Math.round((shelter.currentOccupancy / shelter.capacity) * 100) : 0;
  return (
    <GovCard style={{ marginBottom: 12 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 8 }}>
        <Text style={styles.shelterName} numberOfLines={1}>
          {shelter.name}
        </Text>
        <View style={{ flex: 1 }} />
        <GovPill text={info.displayName} color={info.color} />
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 8 }}>
        <Ionicons name="location" size={12} color="#6C6C70" />
        <Text style={styles.shelterAddress} numberOfLines={1}>
          {shelter.address}
        </Text>
      </View>
      <View style={styles.progressTrack}>
        <View style={[styles.progressFill, { width: `${occupancyPct}%`, backgroundColor: info.color }]} />
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 6 }}>
        <Text style={styles.shelterOccupancy}>
          {shelter.currentOccupancy} / {shelter.capacity} occupied
        </Text>
        <View style={{ flex: 1 }} />
        {shelter.isAccessible && <Ionicons name="accessibility" size={14} color="#6C6C70" style={{ marginRight: 8 }} />}
        {shelter.isPetFriendly && <Ionicons name="paw" size={14} color="#6C6C70" />}
      </View>
    </GovCard>
  );
}

export function ShelterListScreen() {
  const { shelters } = useApp();
  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={styles.content}>
      {shelters.length === 0 ? (
        <GovEmptyState icon="home-outline" title="No Shelters" message="No shelter information available." />
      ) : (
        shelters.map((s) => <ShelterCard key={s.id} shelter={s} />)
      )}
    </ScrollView>
  );
}

export function ChecklistScreen() {
  const [checked, setChecked] = useState({});
  const toggle = (item) => setChecked((prev) => ({ ...prev, [item]: !prev[item] }));
  const checkedCount = Object.values(checked).filter(Boolean).length;

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={styles.content}>
      <GovCard style={{ marginBottom: 16 }}>
        <Text style={styles.checklistProgress}>
          {checkedCount} / {EmergencyChecklist.length} items ready
        </Text>
        <View style={styles.progressTrack}>
          <View
            style={[
              styles.progressFill,
              { width: `${(checkedCount / EmergencyChecklist.length) * 100}%`, backgroundColor: GovPalette.safe },
            ]}
          />
        </View>
      </GovCard>

      {EmergencyChecklist.map((item) => (
        <TouchableOpacity key={item} style={styles.checklistRow} onPress={() => toggle(item)}>
          <Ionicons
            name={checked[item] ? 'checkbox' : 'square-outline'}
            size={22}
            color={checked[item] ? GovPalette.safe : '#8E8E93'}
          />
          <Text style={[styles.checklistText, checked[item] && styles.checklistTextDone]}>{item}</Text>
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
}

export function OfflineGuideScreen() {
  const [expanded, setExpanded] = useState(null);
  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={styles.content}>
      <GovCard style={{ marginBottom: 16, flexDirection: 'row', alignItems: 'center', gap: 10 }}>
        <Ionicons name="cloud-offline" size={18} color={GovPalette.info} />
        <Text style={styles.offlineNote}>This guide works without an internet connection.</Text>
      </GovCard>
      {OfflineGuideSections.map((section) => {
        const isOpen = expanded === section.title;
        return (
          <GovCard key={section.title} style={{ marginBottom: 12 }}>
            <TouchableOpacity
              style={{ flexDirection: 'row', alignItems: 'center' }}
              onPress={() => setExpanded(isOpen ? null : section.title)}
            >
              <Text style={styles.guideSectionTitle}>{section.title}</Text>
              <View style={{ flex: 1 }} />
              <Ionicons name={isOpen ? 'chevron-up' : 'chevron-down'} size={16} color="#6C6C70" />
            </TouchableOpacity>
            {isOpen && <Text style={styles.guideSectionBody}>{section.content}</Text>}
          </GovCard>
        );
      })}
    </ScrollView>
  );
}

export function EmergencyContactsScreen() {
  const { emergencyContacts } = useApp();
  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={styles.content}>
      {emergencyContacts.map((c) => (
        <View key={c.id} style={styles.contactCard}>
          <View style={[styles.contactIconWrap, c.isPrimary && { backgroundColor: withAlpha(GovPalette.emergency, 0.1) }]}>
            <Ionicons name="call" size={18} color={c.isPrimary ? GovPalette.emergency : GovPalette.jungle} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.contactName}>{c.name}</Text>
            <Text style={styles.contactCategory}>{c.category}</Text>
          </View>
          <TouchableOpacity
            style={[styles.callButton, { backgroundColor: c.isPrimary ? GovPalette.emergency : GovPalette.jungle }]}
            onPress={() => Linking.openURL(`tel:${c.number.replace(/[+ ]/g, '')}`)}
          >
            <Text style={styles.callButtonText}>{c.number}</Text>
          </TouchableOpacity>
        </View>
      ))}
    </ScrollView>
  );
}

// The modal quick-access sheet from the Home / Disaster "Emergency" button.
export function EmergencyScreen({ navigation }) {
  const { emergencyContacts } = useApp();
  const primary = emergencyContacts.filter((c) => c.isPrimary);

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={styles.content}>
      <View style={styles.emergencyHero}>
        <Ionicons name="alert-circle" size={40} color={GovPalette.emergency} />
        <Text style={styles.emergencyHeroTitle}>Emergency Assistance</Text>
        <Text style={styles.emergencyHeroDesc}>Tap a number below to call immediately</Text>
      </View>

      {primary.map((c) => (
        <TouchableOpacity
          key={c.id}
          style={styles.bigCallRow}
          onPress={() => Linking.openURL(`tel:${c.number.replace(/[+ ]/g, '')}`)}
        >
          <View style={styles.bigCallIconWrap}>
            <Ionicons name="call" size={22} color="#fff" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.bigCallName}>{c.name}</Text>
            <Text style={styles.bigCallCategory}>{c.category}</Text>
          </View>
          <Text style={styles.bigCallNumber}>{c.number}</Text>
        </TouchableOpacity>
      ))}

      <TouchableOpacity style={styles.moreContactsButton} onPress={() => navigation.navigate('EmergencyContacts')}>
        <Text style={styles.moreContactsText}>View All Emergency Contacts</Text>
        <Ionicons name="chevron-forward" size={16} color={GovPalette.jungle} />
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  content: { padding: 16, paddingBottom: 32 },
  hero: { alignItems: 'center', paddingVertical: 28, borderRadius: Radius.xxl, gap: 8, marginBottom: 16 },
  heroTitle: { fontSize: FontSize.title1, fontWeight: '700', color: '#fff' },
  heroDesc: { fontSize: FontSize.body, color: 'rgba(255,255,255,0.85)', textAlign: 'center', paddingHorizontal: 20 },
  emergencyCallout: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: GovPalette.emergency,
    padding: 16,
    borderRadius: Radius.lg,
    marginBottom: 8,
  },
  emergencyCalloutText: { color: '#fff', fontSize: FontSize.headline, fontWeight: '700' },
  section: { marginTop: 20, gap: 12 },
  grid2: { flexDirection: 'row', gap: 12, marginBottom: 12 },
  quickTile: { flex: 1, alignItems: 'center', paddingVertical: 14, backgroundColor: '#F2F2F7', borderRadius: Radius.lg },
  quickIconWrap: { width: 48, height: 48, borderRadius: Radius.md, alignItems: 'center', justifyContent: 'center', marginBottom: 8 },
  quickTitle: { fontSize: FontSize.body, fontWeight: '500', color: '#1C1C1E' },
  shelterName: { fontSize: FontSize.subheadline, fontWeight: '700', color: '#1C1C1E', flexShrink: 1 },
  shelterAddress: { fontSize: FontSize.caption, color: '#6C6C70', flexShrink: 1 },
  progressTrack: { height: 6, backgroundColor: '#E5E5EA', borderRadius: 3, overflow: 'hidden', marginTop: 4 },
  progressFill: { height: 6, borderRadius: 3 },
  shelterOccupancy: { fontSize: FontSize.sm, color: '#6C6C70' },
  checklistProgress: { fontSize: FontSize.headline, fontWeight: '700', color: '#1C1C1E', marginBottom: 8 },
  checklistRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 12, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: '#E5E5EA' },
  checklistText: { fontSize: FontSize.subheadline, color: '#1C1C1E', flex: 1 },
  checklistTextDone: { textDecorationLine: 'line-through', color: '#8E8E93' },
  offlineNote: { fontSize: FontSize.body, color: '#1C1C1E', flex: 1 },
  guideSectionTitle: { fontSize: FontSize.headline, fontWeight: '700', color: '#1C1C1E' },
  guideSectionBody: { fontSize: FontSize.body, color: '#6C6C70', marginTop: 10, lineHeight: 20 },
  contactCard: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: '#F2F2F7', borderRadius: Radius.lg, padding: 14, marginBottom: 10 },
  contactIconWrap: { width: 40, height: 40, borderRadius: 20, backgroundColor: withAlpha(GovPalette.jungle, 0.1), alignItems: 'center', justifyContent: 'center' },
  contactName: { fontSize: FontSize.subheadline, fontWeight: '600', color: '#1C1C1E' },
  contactCategory: { fontSize: FontSize.caption, color: '#6C6C70' },
  callButton: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: Radius.pill },
  callButtonText: { color: '#fff', fontWeight: '700', fontSize: FontSize.caption },
  emergencyHero: { alignItems: 'center', gap: 8, marginBottom: 20 },
  emergencyHeroTitle: { fontSize: FontSize.title1, fontWeight: '700', color: '#1C1C1E' },
  emergencyHeroDesc: { fontSize: FontSize.body, color: '#6C6C70' },
  bigCallRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    backgroundColor: '#F2F2F7',
    borderRadius: Radius.lg,
    padding: 16,
    marginBottom: 12,
  },
  bigCallIconWrap: { width: 48, height: 48, borderRadius: 24, backgroundColor: GovPalette.emergency, alignItems: 'center', justifyContent: 'center' },
  bigCallName: { fontSize: FontSize.headline, fontWeight: '700', color: '#1C1C1E' },
  bigCallCategory: { fontSize: FontSize.caption, color: '#6C6C70' },
  bigCallNumber: { fontSize: FontSize.headline, fontWeight: '700', color: GovPalette.emergency },
  moreContactsButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 14 },
  moreContactsText: { color: GovPalette.jungle, fontWeight: '600', fontSize: FontSize.subheadline },
});
