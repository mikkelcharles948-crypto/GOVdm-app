import React from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../state/AppContext';
import { GovPalette, FontSize, Radius } from '../theme/theme';
import { GovCard, withAlpha } from '../components/GovComponents';

export default function MoreScreen({ navigation }) {
  const { currentUser, isLoggedIn, isGuest } = useApp();

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={styles.content}>
      <TouchableOpacity style={styles.profileRow} onPress={() => navigation.navigate('Settings')}>
        <View style={styles.avatar}>
          <Ionicons name="person" size={26} color="#fff" />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.profileName}>{isLoggedIn ? currentUser.name : 'Guest User'}</Text>
          <Text style={styles.profileSub}>{isGuest ? 'Tap to create a citizen account' : currentUser.email}</Text>
        </View>
        <Ionicons name="chevron-forward" size={16} color="#8E8E93" />
      </TouchableOpacity>

      <Section title="Discover">
        <Row icon="leaf" title="Tourism" color={GovPalette.safe} onPress={() => navigation.navigate('Tourism')} />
        <Row icon="medkit" title="Health" color={GovPalette.emergency} onPress={() => navigation.navigate('Health')} />
        <Row icon="flower" title="Agriculture & Fisheries" color={GovPalette.jungle} onPress={() => navigation.navigate('Agriculture')} />
      </Section>

      <Section title="My Activity">
        <Row icon="search" title="Track a Report" color={GovPalette.info} onPress={() => navigation.navigate('TrackReport')} />
        <Row icon="laptop-outline" title="My Service Requests" color={GovPalette.gold} onPress={() => navigation.navigate('MyServiceRequests')} />
      </Section>

      <Section title="Disaster Preparedness">
        <Row icon="home" title="Shelter Locator" color={GovPalette.safe} onPress={() => navigation.navigate('ShelterList')} />
        <Row icon="checkbox" title="Emergency Checklist" color={GovPalette.warning} onPress={() => navigation.navigate('Checklist')} />
        <Row icon="book" title="Offline Survival Guide" color={GovPalette.info} onPress={() => navigation.navigate('OfflineGuide')} />
        <Row icon="call" title="Emergency Contacts" color={GovPalette.emergency} onPress={() => navigation.navigate('EmergencyContacts')} />
      </Section>

      <Section title="App">
        <Row icon="search-outline" title="Search" color={GovPalette.jungle} onPress={() => navigation.navigate('Search')} />
        <Row icon="settings" title="Settings" color="#6C6C70" onPress={() => navigation.navigate('Settings')} />
      </Section>
    </ScrollView>
  );
}

function Section({ title, children }) {
  return (
    <View style={{ marginTop: 20 }}>
      <Text style={styles.sectionTitle}>{title}</Text>
      <GovCard style={{ marginTop: 10 }} padding={4}>
        {children}
      </GovCard>
    </View>
  );
}

function Row({ icon, title, color, onPress }) {
  return (
    <TouchableOpacity style={styles.row} onPress={onPress}>
      <View style={[styles.iconWrap, { backgroundColor: withAlpha(color, 0.12) }]}>
        <Ionicons name={icon} size={18} color={color} />
      </View>
      <Text style={styles.rowText}>{title}</Text>
      <View style={{ flex: 1 }} />
      <Ionicons name="chevron-forward" size={14} color="#8E8E93" />
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  content: { padding: 16, paddingBottom: 32 },
  profileRow: { flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: '#F2F2F7', padding: 14, borderRadius: Radius.lg },
  avatar: { width: 48, height: 48, borderRadius: 24, backgroundColor: GovPalette.jungle, alignItems: 'center', justifyContent: 'center' },
  profileName: { fontSize: FontSize.headline, fontWeight: '700', color: '#1C1C1E' },
  profileSub: { fontSize: FontSize.body, color: '#6C6C70', marginTop: 2 },
  sectionTitle: { fontSize: FontSize.caption, fontWeight: '700', color: '#8E8E93', textTransform: 'uppercase', letterSpacing: 0.5 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 12, paddingVertical: 12, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: '#E5E5EA' },
  iconWrap: { width: 36, height: 36, borderRadius: Radius.sm, alignItems: 'center', justifyContent: 'center' },
  rowText: { fontSize: FontSize.subheadline, color: '#1C1C1E', fontWeight: '500' },
});
