import React from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Linking } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { GovPalette, FontSize, Radius } from '../theme/theme';
import { GovCard, GovSectionHeader, withAlpha } from '../components/GovComponents';

// NOTE: AgricultureView.swift was truncated in the uploaded zip after ~41
// lines (it cut off mid-HStack, right after a farmer-support emergency
// row using GovPalette.emergency). This screen reconstructs the rest of
// the module in the same visual language as the other tabs — quick
// actions for farmers/fishers, extension services, and market/weather
// info — since the original content past that point wasn't recoverable.

const services = [
  { icon: 'leaf', title: 'Crop Extension Services', desc: 'Free advice on planting, pest control & soil health' },
  { icon: 'fish', title: 'Fisheries Support', desc: 'Licensing, boat registration & fisher training programs' },
  { icon: 'cash', title: 'Farmer Subsidies', desc: 'Apply for input subsidies, equipment grants & loans' },
  { icon: 'school', title: 'Training Workshops', desc: 'Upcoming workshops on climate-smart agriculture' },
];

export default function AgricultureScreen() {
  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={styles.content}>
      <LinearGradient colors={[GovPalette.jungle, GovPalette.jungleLight]} style={styles.hero}>
        <Ionicons name="leaf" size={36} color="rgba(255,255,255,0.9)" />
        <Text style={styles.heroTitle}>Agriculture & Fisheries</Text>
        <Text style={styles.heroDesc}>Support for Dominica's farmers, fishers & rural communities</Text>
      </LinearGradient>

      <View style={styles.emergencyRow}>
        <Ionicons name="warning" size={18} color={GovPalette.emergency} />
        <Text style={styles.emergencyText}>Report crop disease or livestock outbreak</Text>
        <View style={{ flex: 1 }} />
        <TouchableOpacity style={styles.callButton} onPress={() => Linking.openURL('tel:+17672660141')}>
          <Text style={styles.callButtonText}>Call</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.section}>
        <GovSectionHeader title="Services" />
        {services.map((s) => (
          <GovCard key={s.title} style={{ marginBottom: 12 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
              <View style={[styles.iconWrap, { backgroundColor: withAlpha(GovPalette.jungle, 0.1) }]}>
                <Ionicons name={s.icon} size={20} color={GovPalette.jungle} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.serviceTitle}>{s.title}</Text>
                <Text style={styles.serviceDesc}>{s.desc}</Text>
              </View>
              <Ionicons name="chevron-forward" size={16} color="#8E8E93" />
            </View>
          </GovCard>
        ))}
      </View>

      <View style={styles.section}>
        <GovSectionHeader title="Market Prices Today" />
        <GovCard>
          {[
            ['Dasheen', 'EC$2.50 / lb'],
            ['Plantain', 'EC$1.80 / lb'],
            ['Yam', 'EC$3.00 / lb'],
            ['Fresh Fish (Mahi)', 'EC$12.00 / lb'],
          ].map(([name, price], idx, arr) => (
            <View key={name}>
              <View style={styles.priceRow}>
                <Text style={styles.priceName}>{name}</Text>
                <Text style={styles.priceValue}>{price}</Text>
              </View>
              {idx < arr.length - 1 && <View style={styles.rowDivider} />}
            </View>
          ))}
        </GovCard>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  content: { padding: 16, paddingBottom: 32 },
  hero: { alignItems: 'center', paddingVertical: 28, borderRadius: Radius.xxl, gap: 8, marginBottom: 16 },
  heroTitle: { fontSize: FontSize.title1, fontWeight: '700', color: '#fff' },
  heroDesc: { fontSize: FontSize.body, color: 'rgba(255,255,255,0.8)', textAlign: 'center', paddingHorizontal: 24 },
  emergencyRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: withAlpha(GovPalette.emergency, 0.08),
    padding: 14,
    borderRadius: Radius.lg,
    marginBottom: 8,
  },
  emergencyText: { fontSize: FontSize.body, fontWeight: '500', color: '#1C1C1E', flexShrink: 1 },
  callButton: { backgroundColor: GovPalette.emergency, paddingHorizontal: 16, paddingVertical: 8, borderRadius: Radius.pill },
  callButtonText: { color: '#fff', fontWeight: '700', fontSize: FontSize.caption },
  section: { marginTop: 20, gap: 12 },
  iconWrap: { width: 44, height: 44, borderRadius: Radius.md, alignItems: 'center', justifyContent: 'center' },
  serviceTitle: { fontSize: FontSize.subheadline, fontWeight: '700', color: '#1C1C1E' },
  serviceDesc: { fontSize: FontSize.caption, color: '#6C6C70', marginTop: 2 },
  priceRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 10 },
  priceName: { fontSize: FontSize.subheadline, color: '#1C1C1E' },
  priceValue: { fontSize: FontSize.subheadline, fontWeight: '600', color: GovPalette.jungle },
  rowDivider: { height: StyleSheet.hairlineWidth, backgroundColor: '#E5E5EA' },
});
