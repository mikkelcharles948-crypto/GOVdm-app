// Mock data ported from MockData.swift.
// The original file was truncated in the zip after the first ~2.5
// announcement entries, so the announcements below start with the exact
// recovered content and the rest of the dataset (offices, tourism sites,
// clinics, shelters, alerts, contacts, checklist, guide) has been
// reconstructed to match the app's domain (Dominica government services)
// and the fields referenced throughout the view files.

let idCounter = 1;
const nextId = () => `id_${idCounter++}`;

const daysAgo = (n) => new Date(Date.now() - 86400000 * n).toISOString();

export const Announcements = [
  {
    id: nextId(),
    title: 'Hurricane Season 2026 — Be Prepared',
    summary:
      'The Atlantic hurricane season runs from June 1 to November 30. Citizens are urged to prepare emergency kits and review evacuation routes.',
    body: 'The Office of Disaster Management reminds all citizens and residents that the 2026 Atlantic Hurricane Season is underway. Please ensure your emergency kits are stocked, review your family evacuation plan, and stay tuned to official channels for updates. Shelter locations are available in the Disaster module of this app.',
    priority: 'high',
    department: 'Office of Disaster Management',
    date: daysAgo(2),
    tags: ['hurricane', 'preparedness', 'safety'],
  },
  {
    id: nextId(),
    title: 'New Online Service: Birth Certificate Applications',
    summary:
      'Citizens can now apply for birth certificates digitally through GovDM. Processing time: 3–7 business days.',
    body: "The Registry of the Supreme Court is pleased to announce that birth certificate applications are now available through the GovDM app. This is part of the government's ongoing digital transformation initiative to reduce paperwork and improve service delivery.",
    priority: 'normal',
    department: 'Registry of the Supreme Court',
    date: daysAgo(5),
    tags: ['services', 'digital', 'registry'],
  },
  {
    id: nextId(),
    title: 'Public Consultation: National Development Plan 2030',
    summary:
      'Citizens are invited to share input on the National Development Plan 2030 at parish consultations across Dominica.',
    body: 'The Ministry of Planning and Economic Development invites all citizens to participate in a series of parish-level consultations on the National Development Plan 2030. Sessions will cover economic resilience, climate adaptation, and social development priorities. Locations and times will be posted on the official government website.',
    priority: 'normal',
    department: 'Ministry of Planning and Economic Development',
    date: daysAgo(7),
    tags: ['consultation', 'development', 'planning'],
  },
  {
    id: nextId(),
    title: 'Road Closure: Roseau Valley Road Rehabilitation',
    summary:
      'Roseau Valley Road will be partially closed for rehabilitation works from Monday. Expect delays.',
    body: 'The Ministry of Public Works advises motorists that Roseau Valley Road will undergo rehabilitation works beginning Monday. One lane will remain open with traffic control in place. Motorists are advised to seek alternate routes where possible during peak hours.',
    priority: 'urgent',
    department: 'Ministry of Public Works',
    date: daysAgo(1),
    tags: ['roadworks', 'traffic', 'roseau'],
  },
  {
    id: nextId(),
    title: 'Free Dengue Prevention Health Fair — Portsmouth',
    summary:
      'The Ministry of Health hosts a free health fair in Portsmouth this weekend, focused on dengue prevention and vector control.',
    body: 'Residents of the Portsmouth area are invited to a free health fair featuring dengue prevention education, mosquito control kits, and general health screenings. The event runs from 9am to 3pm at the Portsmouth Health Centre.',
    priority: 'low',
    department: 'Ministry of Health, Wellness and New Health Investment',
    date: daysAgo(10),
    tags: ['health', 'dengue', 'portsmouth'],
  },
];

export const Offices = [
  {
    id: nextId(),
    name: 'Ministry of Finance',
    type: 'ministry',
    parish: 'St. George',
    address: 'Financial Centre, Kennedy Avenue, Roseau',
    phoneNumbers: ['+1 767-266-3476'],
    email: 'info@finance.gov.dm',
    website: 'finance.gov.dm',
    officeHours: 'Mon–Fri, 8:00am–4:00pm',
    departmentHead: 'Permanent Secretary',
    servicesOffered: ['Tax Clearance', 'Customs Enquiries', 'Budget Information'],
    allowsAppointments: true,
    latitude: 15.3017,
    longitude: -61.3883,
  },
  {
    id: nextId(),
    name: 'Registry of the Supreme Court',
    type: 'department',
    parish: 'St. George',
    address: 'Court House, Bath Road, Roseau',
    phoneNumbers: ['+1 767-266-3300'],
    email: 'registry@judiciary.gov.dm',
    website: null,
    officeHours: 'Mon–Fri, 8:30am–4:00pm',
    departmentHead: 'Registrar',
    servicesOffered: ['Birth Certificate', 'Death Certificate', 'Marriage Certificate'],
    allowsAppointments: true,
    latitude: 15.3013,
    longitude: -61.3878,
  },
  {
    id: nextId(),
    name: 'Roseau Central Police Station',
    type: 'policeStation',
    parish: 'St. George',
    address: 'Victoria Street, Roseau',
    phoneNumbers: ['911', '+1 767-448-2222'],
    email: null,
    website: null,
    officeHours: 'Open 24 hours',
    departmentHead: 'Station Commander',
    servicesOffered: ['Crime Reporting', 'Police Records', 'Firearm Licensing'],
    allowsAppointments: false,
    latitude: 15.301,
    longitude: -61.3875,
  },
  {
    id: nextId(),
    name: 'Princess Margaret Hospital',
    type: 'hospital',
    parish: 'St. George',
    address: 'Federation Drive, Goodwill, Roseau',
    phoneNumbers: ['999', '+1 767-448-2231'],
    email: null,
    website: null,
    officeHours: 'Open 24 hours (Emergency)',
    departmentHead: 'Medical Chief of Staff',
    servicesOffered: ['Emergency Care', 'General Medicine', 'Surgery', 'Maternity'],
    allowsAppointments: true,
    latitude: 15.2989,
    longitude: -61.3792,
  },
  {
    id: nextId(),
    name: 'Portsmouth Fire Station',
    type: 'fireStation',
    parish: 'St. John',
    address: 'Bay Street, Portsmouth',
    phoneNumbers: ['999', '+1 767-445-5555'],
    email: null,
    website: null,
    officeHours: 'Open 24 hours',
    departmentHead: 'Fire Chief',
    servicesOffered: ['Fire Response', 'Rescue Services', 'Fire Safety Inspections'],
    allowsAppointments: false,
    latitude: 15.5837,
    longitude: -61.4649,
  },
  {
    id: nextId(),
    name: 'Inland Revenue Division',
    type: 'department',
    parish: 'St. George',
    address: 'Government Headquarters, Kennedy Avenue, Roseau',
    phoneNumbers: ['+1 767-266-3600'],
    email: 'inlandrevenue@dominica.gov.dm',
    website: 'ird.gov.dm',
    officeHours: 'Mon–Fri, 8:00am–4:00pm',
    departmentHead: 'Comptroller',
    servicesOffered: ['Driving License', 'Tax Clearance', 'Vehicle Registration'],
    allowsAppointments: true,
    latitude: 15.302,
    longitude: -61.3885,
  },
  {
    id: nextId(),
    name: 'Marigot Post Office',
    type: 'postOffice',
    parish: 'St. Andrew',
    address: 'Main Road, Marigot',
    phoneNumbers: ['+1 767-445-3268'],
    email: null,
    website: null,
    officeHours: 'Mon–Fri, 8:00am–4:00pm',
    departmentHead: 'Postmaster',
    servicesOffered: ['Mail Services', 'Parcel Collection', 'Money Orders'],
    allowsAppointments: false,
    latitude: 15.5406,
    longitude: -61.2867,
  },
  {
    id: nextId(),
    name: 'Physical Planning Division',
    type: 'department',
    parish: 'St. George',
    address: 'Financial Centre, Kennedy Avenue, Roseau',
    phoneNumbers: ['+1 767-266-3288'],
    email: 'planning@dominica.gov.dm',
    website: null,
    officeHours: 'Mon–Fri, 8:00am–4:00pm',
    departmentHead: 'Chief Physical Planner',
    servicesOffered: ['Building Permit', 'Land Use Approval', 'Development Control'],
    allowsAppointments: true,
    latitude: 15.3019,
    longitude: -61.3881,
  },
];

export const TourismSites = [
  {
    id: nextId(),
    name: 'Boiling Lake',
    description:
      'The second-largest hot lake in the world, tucked in Morne Trois Pitons National Park — a UNESCO World Heritage Site. A challenging but unforgettable hike.',
    category: 'hikingTrail',
    parish: 'St. Paul',
    entryFee: 'EC$5 park fee',
    rating: 4.8,
    tips: [
      'Start early — the hike takes 6–7 hours round trip',
      'Wear sturdy hiking boots',
      'Hire a certified local guide',
    ],
    latitude: 15.324,
    longitude: -61.293,
  },
  {
    id: nextId(),
    name: 'Champagne Reef',
    description:
      'A unique snorkeling spot where volcanic vents release warm bubbles through the seabed, creating a natural "champagne" effect underwater.',
    category: 'beach',
    parish: 'St. Paul',
    entryFee: 'EC$2 site fee',
    rating: 4.7,
    tips: ['Bring your own snorkel gear or rent locally', 'Best visited in the morning'],
    latitude: 15.2611,
    longitude: -61.3711,
  },
  {
    id: nextId(),
    name: 'Trafalgar Falls',
    description:
      'Twin waterfalls known as "Mother" and "Father" falls, framed by lush rainforest and accessible via a short scenic trail.',
    category: 'waterfall',
    parish: 'St. George',
    entryFee: 'EC$5 site fee',
    rating: 4.6,
    tips: ['Trail can be slippery — wear grip footwear', 'Combine with a visit to Papillote hot springs'],
    latitude: 15.302,
    longitude: -61.3389,
  },
  {
    id: nextId(),
    name: 'Emerald Pool',
    description:
      'A serene rainforest pool fed by a cascading waterfall, reachable via an easy 20-minute nature trail.',
    category: 'nationalPark',
    parish: 'St. George',
    entryFee: 'EC$5 park fee',
    rating: 4.5,
    tips: ['Great for families', 'Bring water shoes for the pool'],
    latitude: 15.3608,
    longitude: -61.3244,
  },
  {
    id: nextId(),
    name: "Wotten Waven Sulphur Springs",
    description:
      'Natural hot sulphur pools nestled in the village of Wotten Waven, popular for their therapeutic properties.',
    category: 'hotSprings',
    parish: 'St. George',
    entryFee: 'EC$10–20 depending on operator',
    rating: 4.4,
    tips: ['Several operators offer private and shared pools', 'Sulphur smell is normal'],
    latitude: 15.3167,
    longitude: -61.3494,
  },
  {
    id: nextId(),
    name: 'Fort Shirley',
    description:
      'A restored 18th-century British garrison overlooking the Cabrits National Park and Prince Rupert Bay.',
    category: 'historicSite',
    parish: 'St. John',
    entryFee: 'EC$10 site fee',
    rating: 4.5,
    tips: ['Visit the on-site museum', 'Combine with a Cabrits National Park hike'],
    latitude: 15.5883,
    longitude: -61.4711,
  },
];

export const Clinics = [
  {
    id: nextId(),
    name: 'Princess Margaret Hospital',
    isHospital: true,
    parish: 'St. George',
    address: 'Federation Drive, Goodwill, Roseau',
    hours: 'Open 24 hours (Emergency)',
    phone: '+1 767-448-2231',
    services: ['Emergency Care', 'Surgery', 'Maternity', 'Radiology', 'Laboratory'],
  },
  {
    id: nextId(),
    name: 'Portsmouth Hospital',
    isHospital: true,
    parish: 'St. John',
    address: 'Bay Street, Portsmouth',
    hours: 'Open 24 hours (Emergency)',
    phone: '+1 767-445-5237',
    services: ['Emergency Care', 'General Medicine', 'Maternity'],
  },
  {
    id: nextId(),
    name: 'Grand Bay Health Centre',
    isHospital: false,
    parish: 'St. Patrick',
    address: 'Main Road, Grand Bay',
    hours: 'Mon–Fri, 8:00am–4:00pm',
    phone: '+1 767-446-3103',
    services: ['General Medicine', 'Vaccinations', 'Maternal Health'],
  },
  {
    id: nextId(),
    name: 'Marigot Health Centre',
    isHospital: false,
    parish: 'St. Andrew',
    address: 'Main Road, Marigot',
    hours: 'Mon–Fri, 8:00am–4:00pm',
    phone: '+1 767-445-3232',
    services: ['General Medicine', 'Vaccinations', 'Dental'],
  },
  {
    id: nextId(),
    name: 'Grand Fond Health Centre',
    isHospital: false,
    parish: 'St. David',
    address: 'Main Road, Grand Fond',
    hours: 'Mon–Fri, 8:00am–4:00pm',
    phone: '+1 767-446-4222',
    services: ['General Medicine', 'Vaccinations'],
  },
];

export const HealthCampaigns = [
  {
    id: nextId(),
    title: 'Dengue Prevention Drive 2026',
    description:
      'Islandwide effort to eliminate mosquito breeding sites and distribute repellent kits to vulnerable households.',
    targetGroup: 'All Residents',
    location: 'Islandwide',
    isActive: true,
  },
  {
    id: nextId(),
    title: 'Childhood Immunization Catch-up',
    description:
      'Free catch-up vaccinations for children who missed scheduled immunizations during the past year.',
    targetGroup: 'Children under 12',
    location: 'All Health Centres',
    isActive: true,
  },
  {
    id: nextId(),
    title: 'Hypertension & Diabetes Screening',
    description: 'Free blood pressure and glucose screening for residents 40 and older.',
    targetGroup: 'Adults 40+',
    location: 'Roseau & Portsmouth',
    isActive: false,
  },
];

export const Shelters = [
  {
    id: nextId(),
    name: 'St. Mary Academy Shelter',
    parish: 'St. George',
    address: 'Newtown, Roseau',
    capacity: 250,
    currentOccupancy: 12,
    status: 'open',
    isAccessible: true,
    isPetFriendly: false,
    contactPhone: '+17672664414',
  },
  {
    id: nextId(),
    name: 'Portsmouth Primary School Shelter',
    parish: 'St. John',
    address: 'Bay Street, Portsmouth',
    capacity: 180,
    currentOccupancy: 165,
    status: 'limited',
    isAccessible: true,
    isPetFriendly: false,
    contactPhone: '+17674455555',
  },
  {
    id: nextId(),
    name: 'Grand Bay Community Centre',
    parish: 'St. Patrick',
    address: 'Main Road, Grand Bay',
    capacity: 120,
    currentOccupancy: 0,
    status: 'closed',
    isAccessible: false,
    isPetFriendly: true,
    contactPhone: null,
  },
  {
    id: nextId(),
    name: 'Marigot Secondary School Shelter',
    parish: 'St. Andrew',
    address: 'Main Road, Marigot',
    capacity: 200,
    currentOccupancy: 200,
    status: 'full',
    isAccessible: true,
    isPetFriendly: false,
    contactPhone: '+17674453232',
  },
];

export const EmergencyAlerts = [
  {
    id: nextId(),
    type: 'hurricane',
    severity: 'watch',
    title: 'Tropical Storm Watch Issued',
    message:
      'The National Hurricane Centre has issued a Tropical Storm Watch for Dominica. Monitor official channels and prepare your emergency kit.',
    isActive: true,
  },
  {
    id: nextId(),
    type: 'flood',
    severity: 'warning',
    title: 'Flash Flood Warning — Layou River',
    message:
      'Heavy rainfall has raised water levels in the Layou River. Residents in low-lying areas are advised to move to higher ground.',
    isActive: true,
  },
];

export const EmergencyContacts = [
  { id: nextId(), name: 'Police Emergency', category: 'Police', number: '911', isPrimary: true },
  { id: nextId(), name: 'Fire & Ambulance', category: 'Fire / Medical', number: '999', isPrimary: true },
  {
    id: nextId(),
    name: 'Office of Disaster Management',
    category: 'Disaster Management',
    number: '+17672664414',
    isPrimary: true,
  },
  {
    id: nextId(),
    name: 'Princess Margaret Hospital',
    category: 'Hospital',
    number: '+17674482231',
    isPrimary: false,
  },
  { id: nextId(), name: 'DOWASCO (Water)', category: 'Utilities', number: '+17674486868', isPrimary: false },
  { id: nextId(), name: 'DOMLEC (Electricity)', category: 'Utilities', number: '+17672550600', isPrimary: false },
];

export const EmergencyChecklist = [
  'Water (1 gallon per person, per day, for 7 days)',
  'Non-perishable food (7-day supply)',
  'Battery-powered or hand-crank radio',
  'Flashlight and extra batteries',
  'First aid kit',
  'Whistle to signal for help',
  'Dust masks and plastic sheeting',
  'Moist towelettes, garbage bags, plastic ties',
  'Wrench or pliers to turn off utilities',
  'Manual can opener',
  'Local maps',
  'Cell phone with chargers and a backup battery',
  'Prescription medications and glasses',
  'Copies of important documents (IDs, insurance, bank records)',
  'Cash in small denominations',
  'Emergency contact information',
  'Sleeping bag or warm blanket per person',
  'Complete change of clothing per person',
  'Fire extinguisher',
  'Matches in a waterproof container',
];

export const OfflineGuideSections = [
  {
    title: 'Hurricane',
    content:
      'Secure loose outdoor items, board up windows, and identify your nearest shelter. Fill bathtubs and containers with water. Charge all devices. Stay indoors away from windows during the storm and monitor official radio broadcasts.',
  },
  {
    title: 'Earthquake',
    content:
      'Drop, Cover, and Hold On. Get under sturdy furniture and away from windows. If outdoors, move to an open area away from buildings and power lines. After shaking stops, check for injuries and hazards like gas leaks before evacuating.',
  },
  {
    title: 'Flood',
    content:
      'Move to higher ground immediately. Avoid walking or driving through flood water — six inches of moving water can knock you down. Stay away from downed power lines and follow evacuation orders from local authorities.',
  },
  {
    title: 'Landslide',
    content:
      'Watch for warning signs: cracking trees, tilting trees or poles, and rumbling sounds. If you suspect imminent danger, evacuate immediately. Avoid river valleys and steep slopes during and after heavy rainfall.',
  },
  {
    title: 'Tsunami',
    content:
      'If you feel a strong earthquake near the coast, move inland and to higher ground immediately — do not wait for an official warning. Stay away from the coast until authorities confirm it is safe to return.',
  },
  {
    title: 'Volcanic Activity',
    content:
      'Follow evacuation orders from the Office of Disaster Management immediately. Wear a mask or damp cloth over your mouth if ashfall occurs, and keep vehicle and home windows closed.',
  },
  {
    title: 'Fire',
    content:
      'Get out immediately and stay low to avoid smoke inhalation. Call 999 once safely outside. Never re-enter a burning building. Have a family meeting point planned in advance.',
  },
];

export { nextId };
