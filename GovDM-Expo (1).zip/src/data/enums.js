// Enum-style definitions ported from the SwiftUI app's Models.swift.
//
// NOTE ON RECONSTRUCTION: the uploaded Xcode project's Models.swift,
// Theme.swift, GovComponents.swift, AppViewModel.swift, MockData.swift and
// AgricultureView.swift were truncated mid-file in the zip (they cut off
// mid-statement). Everything below that isn't directly visible in the
// working view files (ReportStatus + its color, and the status color
// constants) has been reconstructed from how it's used across the 9
// complete screens, so it matches the app's behavior and look even though
// the original literal source for these specific pieces wasn't recoverable.
import { GovPalette } from '../theme/theme';

// MARK: - Report Status
export const ReportStatus = {
  submitted: 'submitted',
  received: 'received',
  assigned: 'assigned',
  inProgress: 'inProgress',
  waitingInfo: 'waitingInfo',
  resolved: 'resolved',
  closed: 'closed',
  rejected: 'rejected',
};

export const ReportStatusInfo = {
  submitted: { displayName: 'Submitted', color: GovPalette.statusSubmitted },
  received: { displayName: 'Received', color: GovPalette.statusReceived },
  assigned: { displayName: 'Assigned', color: GovPalette.statusAssigned },
  inProgress: { displayName: 'In Progress', color: GovPalette.statusInProgress },
  waitingInfo: { displayName: 'Waiting Information', color: GovPalette.statusWaitingInfo },
  resolved: { displayName: 'Resolved', color: GovPalette.statusResolved },
  closed: { displayName: 'Closed', color: GovPalette.statusClosed },
  rejected: { displayName: 'Rejected', color: GovPalette.statusRejected },
};

// MARK: - Report Category
export const ReportCategoryInfo = {
  roadDamage: { displayName: 'Road Damage', icon: 'construct', color: GovPalette.warning },
  crime: { displayName: 'Crime', icon: 'shield-half', color: GovPalette.emergency },
  corruption: { displayName: 'Corruption', icon: 'alert-circle', color: GovPalette.coral },
  sanitation: { displayName: 'Sanitation', icon: 'trash', color: GovPalette.safe },
  utilities: { displayName: 'Utilities', icon: 'flash', color: GovPalette.info },
  publicSafety: { displayName: 'Public Safety', icon: 'warning', color: GovPalette.emergency },
  environment: { displayName: 'Environment', icon: 'leaf', color: GovPalette.jungle },
  other: { displayName: 'Other', icon: 'ellipsis-horizontal-circle', color: GovPalette.ocean },
};
export const ReportCategoryList = Object.keys(ReportCategoryInfo);

// MARK: - Announcement Priority
export const AnnouncementPriorityInfo = {
  urgent: { displayName: 'Urgent', icon: 'alert-circle', color: GovPalette.emergency },
  high: { displayName: 'High', icon: 'arrow-up-circle', color: GovPalette.warning },
  normal: { displayName: 'Normal', icon: 'information-circle', color: GovPalette.info },
  low: { displayName: 'Low', icon: 'checkmark-circle', color: GovPalette.safe },
};
export const AnnouncementPriorityList = Object.keys(AnnouncementPriorityInfo);

// MARK: - Office Type
export const OfficeTypeInfo = {
  ministry: { displayName: 'Ministry', icon: 'business', color: GovPalette.jungle },
  department: { displayName: 'Department', icon: 'file-tray-full', color: GovPalette.info },
  council: { displayName: 'Council', icon: 'people', color: GovPalette.gold },
  policeStation: { displayName: 'Police Station', icon: 'shield-half', color: GovPalette.info },
  fireStation: { displayName: 'Fire Station', icon: 'flame', color: GovPalette.emergency },
  hospital: { displayName: 'Hospital', icon: 'medkit', color: GovPalette.emergency },
  courtHouse: { displayName: 'Court House', icon: 'hammer', color: GovPalette.jungleLight },
  postOffice: { displayName: 'Post Office', icon: 'mail', color: GovPalette.ocean },
  other: { displayName: 'Other', icon: 'ellipsis-horizontal-circle', color: GovPalette.ocean },
};
export const OfficeTypeList = Object.keys(OfficeTypeInfo);

// MARK: - Service Request Type
export const ServiceRequestTypeInfo = {
  birthCertificate: {
    displayName: 'Birth Certificate',
    icon: 'document-text',
    department: 'Registry of the Supreme Court',
    processingTime: '3–7 business days',
  },
  deathCertificate: {
    displayName: 'Death Certificate',
    icon: 'document-text',
    department: 'Registry of the Supreme Court',
    processingTime: '3–7 business days',
  },
  marriageCertificate: {
    displayName: 'Marriage Certificate',
    icon: 'heart',
    department: 'Registry of the Supreme Court',
    processingTime: '5–10 business days',
  },
  passportApplication: {
    displayName: 'Passport Application',
    icon: 'airplane',
    department: 'Immigration Department',
    processingTime: '10–15 business days',
  },
  drivingLicense: {
    displayName: 'Driving License',
    icon: 'car',
    department: 'Inland Revenue Division',
    processingTime: '5–7 business days',
  },
  buildingPermit: {
    displayName: 'Building Permit',
    icon: 'hammer',
    department: 'Physical Planning Division',
    processingTime: '15–20 business days',
  },
  businessLicense: {
    displayName: 'Business License',
    icon: 'briefcase',
    department: 'Trade, Innovation & Business Development',
    processingTime: '7–10 business days',
  },
  taxClearance: {
    displayName: 'Tax Clearance',
    icon: 'cash',
    department: 'Inland Revenue Division',
    processingTime: '3–5 business days',
  },
  voterRegistration: {
    displayName: 'Voter Registration',
    icon: 'checkbox',
    department: 'Electoral Office',
    processingTime: '1–3 business days',
  },
};
export const ServiceRequestTypeList = Object.keys(ServiceRequestTypeInfo);

// MARK: - Public Works Type
export const PublicWorksTypeInfo = {
  pothole: { displayName: 'Pothole', icon: 'warning' },
  streetlight: { displayName: 'Streetlight Outage', icon: 'bulb' },
  drainage: { displayName: 'Blocked Drainage', icon: 'water' },
  landslide: { displayName: 'Landslide', icon: 'triangle' },
  roadClosure: { displayName: 'Road Closure', icon: 'close-circle' },
  waterMain: { displayName: 'Water Main Break', icon: 'water' },
  other: { displayName: 'Other', icon: 'ellipsis-horizontal-circle' },
};
export const PublicWorksTypeList = Object.keys(PublicWorksTypeInfo);

// MARK: - Tourism Category
export const TourismCategoryInfo = {
  beach: { displayName: 'Beach', icon: 'sunny' },
  waterfall: { displayName: 'Waterfall', icon: 'water' },
  nationalPark: { displayName: 'National Park', icon: 'leaf' },
  historicSite: { displayName: 'Historic Site', icon: 'business' },
  hotSprings: { displayName: 'Hot Springs', icon: 'flame' },
  hikingTrail: { displayName: 'Hiking Trail', icon: 'walk' },
};
export const TourismCategoryList = Object.keys(TourismCategoryInfo);

// MARK: - Alert Type / Severity
export const AlertTypeInfo = {
  hurricane: { displayName: 'Hurricane', icon: 'thunderstorm' },
  flood: { displayName: 'Flood', icon: 'water' },
  earthquake: { displayName: 'Earthquake', icon: 'pulse' },
  tsunami: { displayName: 'Tsunami', icon: 'water' },
  landslide: { displayName: 'Landslide', icon: 'triangle' },
  fire: { displayName: 'Fire', icon: 'flame' },
  publicHealth: { displayName: 'Public Health', icon: 'medkit' },
};

export const AlertSeverityInfo = {
  watch: { displayName: 'Watch', color: GovPalette.info },
  warning: { displayName: 'Warning', color: GovPalette.warning },
  emergency: { displayName: 'Emergency', color: GovPalette.emergency },
};

// MARK: - Shelter Status
export const ShelterStatusInfo = {
  open: { displayName: 'Open', color: GovPalette.safe },
  limited: { displayName: 'Limited Space', color: GovPalette.warning },
  full: { displayName: 'Full', color: GovPalette.emergency },
  closed: { displayName: 'Closed', color: GovPalette.statusClosed },
};

// MARK: - Parish
export const AllParishes = [
  'St. George',
  'St. Andrew',
  'St. David',
  'St. John',
  'St. Joseph',
  'St. Luke',
  'St. Mark',
  'St. Patrick',
  'St. Paul',
  'St. Peter',
];
export const DefaultParish = 'St. George';

// MARK: - App Language
export const AppLanguageInfo = {
  english: { displayName: 'English', flag: 'EN' },
  french: { displayName: 'Français', flag: 'FR' },
  creole: { displayName: 'Kwéyòl', flag: 'KW' },
};
export const AppLanguageList = Object.keys(AppLanguageInfo);
