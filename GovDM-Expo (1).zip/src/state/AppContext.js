import React, { createContext, useContext, useMemo, useState, useCallback } from 'react';
import {
  Announcements,
  Offices,
  TourismSites,
  Clinics,
  HealthCampaigns,
  Shelters,
  EmergencyAlerts,
  EmergencyContacts,
} from '../data/mockData';
import { DefaultParish } from '../data/enums';

// Root application state — manages user account, reports, service requests,
// theme, language, and accessibility preferences.
// Ported from AppViewModel.swift (@Observable final class AppViewModel).
// The Swift source for this file was truncated in the zip after the
// "// MARK: - Data" comment, so the report/service-request/favorites state
// and all the action methods below were reconstructed from how every screen
// in the app calls into `viewModel`.

const AppContext = createContext(null);

let trackingCounter = Date.now();
function generateTrackingCode(prefix) {
  trackingCounter += 1;
  return `${prefix}-${trackingCounter}`;
}

const GuestUser = {
  role: 'guest',
  isLoggedIn: false,
  name: '',
  email: '',
  phone: '',
  parish: DefaultParish,
};

export function AppProvider({ children }) {
  // User
  const [currentUser, setCurrentUser] = useState(GuestUser);
  const [hasCompletedOnboarding, setHasCompletedOnboarding] = useState(false);

  // Theme / accessibility / language
  const [colorScheme, setColorScheme] = useState(null); // null = system
  const [largeText, setLargeText] = useState(false);
  const [highContrast, setHighContrast] = useState(false);
  const [reduceMotion, setReduceMotion] = useState(false);
  const [language, setLanguage] = useState('english');

  // Data
  const [reports, setReports] = useState([]);
  const [serviceRequests, setServiceRequests] = useState([]);
  const [favoriteOffices, setFavoriteOffices] = useState([]);

  const isLoggedIn = currentUser.isLoggedIn;
  const isGuest = currentUser.role === 'guest';

  const loginAsGuest = useCallback(() => {
    setCurrentUser(GuestUser);
    setHasCompletedOnboarding(true);
  }, []);

  const loginAsCitizen = useCallback((name, email, phone, parish) => {
    setCurrentUser({ role: 'citizen', isLoggedIn: true, name, email, phone, parish });
  }, []);

  const completeOnboarding = useCallback(() => setHasCompletedOnboarding(true), []);

  const logout = useCallback(() => {
    setCurrentUser(GuestUser);
  }, []);

  const updateLanguage = useCallback((lang) => setLanguage(lang), []);
  const toggleLargeText = useCallback(() => setLargeText((v) => !v), []);
  const toggleHighContrast = useCallback(() => setHighContrast((v) => !v), []);
  const toggleReduceMotion = useCallback(() => setReduceMotion((v) => !v), []);

  const submitReport = useCallback((report) => {
    const now = new Date().toISOString();
    const trackingCode = generateTrackingCode('RPT');
    const withCode = {
      ...report,
      id: `report_${trackingCounter}`,
      trackingCode,
      createdAt: now,
      updatedAt: now,
      statusHistory: [{ id: `su_${trackingCounter}`, status: 'submitted', note: 'Report received by GovDM.', date: now }],
    };
    setReports((prev) => [withCode, ...prev]);
  }, []);

  const submitServiceRequest = useCallback((request) => {
    const now = new Date().toISOString();
    const trackingCode = generateTrackingCode('SRV');
    const withCode = {
      ...request,
      id: `svc_${trackingCounter}`,
      trackingCode,
      status: 'submitted',
      createdAt: now,
    };
    setServiceRequests((prev) => [withCode, ...prev]);
  }, []);

  const toggleFavoriteOffice = useCallback((officeId) => {
    setFavoriteOffices((prev) =>
      prev.includes(officeId) ? prev.filter((id) => id !== officeId) : [...prev, officeId]
    );
  }, []);

  const reportByTrackingCode = useCallback(
    (code) => reports.find((r) => r.trackingCode.toLowerCase() === code.trim().toLowerCase()) || null,
    [reports]
  );

  const value = useMemo(
    () => ({
      // user
      currentUser,
      isLoggedIn,
      isGuest,
      hasCompletedOnboarding,
      loginAsGuest,
      loginAsCitizen,
      completeOnboarding,
      logout,

      // theme / accessibility / language
      colorScheme,
      setColorScheme,
      largeText,
      toggleLargeText,
      highContrast,
      toggleHighContrast,
      reduceMotion,
      toggleReduceMotion,
      language,
      updateLanguage,

      // static reference data
      announcements: Announcements,
      offices: Offices,
      tourismSites: TourismSites,
      clinics: Clinics,
      healthCampaigns: HealthCampaigns,
      shelters: Shelters,
      emergencyAlerts: EmergencyAlerts,
      emergencyContacts: EmergencyContacts,

      // user-generated data
      reports,
      serviceRequests,
      favoriteOffices,
      submitReport,
      submitServiceRequest,
      toggleFavoriteOffice,
      reportByTrackingCode,
    }),
    [
      currentUser,
      isLoggedIn,
      isGuest,
      hasCompletedOnboarding,
      loginAsGuest,
      loginAsCitizen,
      completeOnboarding,
      logout,
      colorScheme,
      largeText,
      toggleLargeText,
      highContrast,
      toggleHighContrast,
      reduceMotion,
      toggleReduceMotion,
      language,
      updateLanguage,
      reports,
      serviceRequests,
      favoriteOffices,
      submitReport,
      submitServiceRequest,
      toggleFavoriteOffice,
      reportByTrackingCode,
    ]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
