// Color palette for GovDM — inspired by Dominica's national colors
// (jungle green, gold) with a modern, professional government aesthetic.
// Ported 1:1 from the SwiftUI GovPalette enum (Theme.swift).
export const GovPalette = {
  // Primary brand — deep jungle green
  jungle: '#0A3D2E',
  jungleLight: '#145C42',
  jungleDark: '#052920',

  // Accent — refined gold
  gold: '#E8B931',
  goldSoft: '#F2D973',

  // Caribbean accents (used sparingly)
  ocean: '#0073A0',
  coral: '#EB544F',

  // Semantic
  emergency: '#C71C24',
  warning: '#F5A623',
  safe: '#2E9E61',
  info: '#2173D1',

  // Status colors for reports / service requests
  statusSubmitted: '#737480',
  statusReceived: '#3380D9',
  statusAssigned: '#8C66D9',
  statusInProgress: '#E69919',
  statusWaitingInfo: '#D98A19',
  statusResolved: '#2E9E61',
  statusClosed: '#737480',
  statusRejected: '#C71C24',

  white: '#FFFFFF',
  black: '#000000',
};

// Approximate iOS system background equivalents, since RN has no
// systemBackground/secondarySystemBackground/tertiarySystemBackground.
export const SystemColors = {
  light: {
    background: '#FFFFFF',
    secondaryBackground: '#F2F2F7',
    tertiaryBackground: '#E5E5EA',
    label: '#1C1C1E',
    secondaryLabel: '#6C6C70',
    separator: '#D1D1D6',
  },
  dark: {
    background: '#000000',
    secondaryBackground: '#1C1C1E',
    tertiaryBackground: '#2C2C2E',
    label: '#FFFFFF',
    secondaryLabel: '#AEAEB2',
    separator: '#38383A',
  },
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
};

export const Radius = {
  sm: 8,
  md: 12,
  lg: 14,
  xl: 16,
  xxl: 20,
  pill: 999,
};

export const FontSize = {
  xs: 10,
  sm: 11,
  caption: 12,
  body: 13,
  callout: 14,
  subheadline: 15,
  headline: 16,
  title3: 18,
  title2: 20,
  title1: 24,
  largeTitle: 26,
  hero: 38,
};
