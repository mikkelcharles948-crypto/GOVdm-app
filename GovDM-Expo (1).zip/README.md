# GovDM — Expo / React Native

This is a full conversion of the GovDM SwiftUI app (Dominica Citizen Services) into
an Expo-managed React Native project, using React Navigation. It's structured so you
can import the whole folder directly into **Expo Snack** (or run locally with
`npm install && npx expo start`).

## Important: about the source files

Six files in the uploaded Xcode project were **truncated mid-statement** in the zip
(they simply cut off partway through a line):

- `Models.swift`
- `Theme.swift`
- `DesignSystem/GovComponents.swift`
- `ViewModels/AppViewModel.swift`
- `Services/MockData.swift`
- `Views/Agriculture/AgricultureView.swift`

The other 9 screen files (Home, Office Directory, Search, Reports, Services,
Health, Tourism, Disaster, Settings, Onboarding, MainTabView — about 5,300 lines)
were complete and were ported directly, including their real copy/content.

For the 6 truncated files, everything not visible in the recoverable fragment was
**reconstructed** from how each screen actually calls into models, theme colors,
components, and view-model state — so the app should look and behave the same, but
a few specifics (e.g. exact mock announcement copy past what was recoverable, or the
Agriculture screen's content past line 41) are best-effort recreations rather than
literal ports. These spots are flagged with comments in the source (search for
"truncated" or "reconstructed").

## Project structure

```
App.js                        Root navigation (stack + tabs)
src/
  theme/theme.js               GovPalette colors, spacing, fonts
  data/enums.js                Report/Office/Service/Tourism/Alert categories
  data/mockData.js              Seeded content (announcements, offices, sites...)
  state/AppContext.js           Global app state (replaces AppViewModel)
  components/GovComponents.js   Shared UI: GovCard, GovPill, GovStatusBadge, etc.
  navigation/MainTabs.js         Bottom tab bar (Home / Directory / Services / Disaster / More)
  screens/                      One file per SwiftUI view module
```

## Notable adaptations from SwiftUI → React Native

- SwiftUI's `.sheet()` modals became React Navigation screens with
  `presentation: 'modal'` (Login, Search, New Report, New Service Request, Track
  Report, Emergency).
- SF Symbols were mapped to the closest `Ionicons` equivalents (from
  `@expo/vector-icons`, bundled with Expo — no extra setup needed).
- The custom `FlowLayout` (wrapping chip layout) became a simple `flexWrap` row.
- Persistence: like the original in-memory `@Observable` view model, all state
  (reports, service requests, favorites, accessibility settings) lives in React
  state for the session — nothing is written to disk, matching a quick Snack/demo
  setup. If you want it to persist between app launches, swap `AppContext.js`'s
  `useState` calls for `AsyncStorage`-backed state.

## Running it

**In Expo Snack:** create a new Snack, then upload/paste in all files under this
folder keeping the same paths (`App.js` at the root, everything else under `src/`).

**Locally:**
```bash
npm install
npx expo start
```
